plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "tv.orbita.player"
    compileSdk = 35

    defaultConfig {
        applicationId = "tv.orbita.player"
        minSdk = 22          // Fire TV Stick di prima generazione (Fire OS 5)
        targetSdk = 35
        versionCode = 6
        versionName = "1.3.1"
    }

    // Chiave fissa inclusa nel progetto: ogni nuova build si installa sopra la precedente
    // senza perdere playlist, preferiti e cronologia. Va bene per un'app personale.
    signingConfigs {
        create("orbita") {
            storeFile = file("orbita.keystore")
            storePassword = "orbita-tv"
            keyAlias = "orbita"
            keyPassword = "orbita-tv"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("orbita")
        }
        debug {
            signingConfig = signingConfigs.getByName("orbita")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        buildConfig = true
    }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

dependencies {
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.5.1")
    implementation("androidx.media3:media3-ui:1.5.1")
    implementation("androidx.annotation:annotation-experimental:1.4.1")
}
