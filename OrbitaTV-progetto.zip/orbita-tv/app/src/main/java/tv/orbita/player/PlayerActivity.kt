package tv.orbita.player

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.LoadControl
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import androidx.media3.ui.SubtitleView
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * Lettore video nativo (Media3/ExoPlayer): HLS, MPEG-TS, MP4, MKV.
 *
 * Preferenze ricevute dall'interfaccia (payload.prefs):
 *  - buffer: "standard" | "large" | "max"
 *  - audioLang: codice lingua preferita per l'audio ("it", "en", "" = traccia predefinita)
 *  - subLang: "off" | "it" | "en" (sottotitoli forzati sempre mostrati)
 *  - subSize: "s" | "m" | "l" | "xl";  subBg: sfondo scuro dietro i sottotitoli
 *
 * Telecomando:
 *  - Su/Giù o CH+/CH- in diretta: canale precedente/successivo della stessa categoria
 *  - Sinistra/Destra (film e serie, comandi nascosti): -10 s / +10 s
 *  - Riavvolgi/Avanti veloce: -30 s / +30 s
 *  - Menu: formato immagine (adatta, zoom, riempi)
 *  - Centrale: mostra i comandi (audio, sottotitoli e velocità sono nell'icona impostazioni)
 *  - Indietro: torna al catalogo e salva il punto di visione
 */
@OptIn(UnstableApi::class)
class PlayerActivity : Activity() {

    private data class Entry(
        val url: String,
        val title: String,
        val subtitle: String,
        val key: String,
        val mime: String?,
        val alts: List<String>
    )

    private lateinit var player: ExoPlayer
    private lateinit var view: PlayerView
    private lateinit var info: TextView

    private val entries = ArrayList<Entry>()
    private var index = 0
    private var live = false
    private var retries = 0
    private var altIdx = 0
    private var lastGoodPosition = 0L
    private var currentRecorded = false
    private var finishing = false
    private val updates = JSONArray()
    private val handler = Handler(Looper.getMainLooper())
    private val hideInfo = Runnable { info.visibility = View.GONE }

    private val resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
        AspectRatioFrameLayout.RESIZE_MODE_FILL
    )
    private val resizeNames = arrayOf("Adatta", "Zoom", "Riempi")
    private var resizeIdx = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        view = findViewById(R.id.player_view)
        info = findViewById(R.id.info)

        val p = try {
            JSONObject(intent.getStringExtra("payload") ?: "{}")
        } catch (e: Exception) {
            JSONObject()
        }
        val prefs = p.optJSONObject("prefs") ?: JSONObject()
        live = p.optBoolean("live", false)
        val ua = p.optString("ua", "").ifBlank { MainActivity.DEFAULT_UA }

        val list = p.optJSONArray("playlist")
        if (list != null && list.length() > 0) {
            for (i in 0 until list.length()) entries.add(parse(list.getJSONObject(i)))
            index = p.optInt("index", 0).coerceIn(0, entries.size - 1)
        } else {
            entries.add(parse(p))
        }
        if (entries.isEmpty() || entries[index].url.isBlank()) {
            Toast.makeText(this, "Nessun indirizzo da riprodurre", Toast.LENGTH_LONG).show()
            finishWithResult()
            return
        }

        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(ua)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(30000)

        val renderers = DefaultRenderersFactory(this).setEnableDecoderFallback(true)

        player = ExoPlayer.Builder(this, renderers)
            .setLoadControl(loadControl(prefs.optString("buffer", "standard")))
            .setMediaSourceFactory(DefaultMediaSourceFactory(this).setDataSourceFactory(http))
            .build()

        applyTrackPrefs(prefs)

        view.player = player
        view.controllerAutoShow = false
        view.setShowSubtitleButton(true)
        view.keepScreenOn = true
        if (live) {
            view.setShowFastForwardButton(false)
            view.setShowRewindButton(false)
        }
        applySubtitleStyle(prefs)

        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) retries = 0
                if (state == Player.STATE_ENDED && !live) {
                    record(true)
                    if (index < entries.size - 1) {
                        index++
                        startCurrent(0)
                    } else {
                        finishWithResult()
                    }
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                // Prima prova le altre versioni dello stesso canale (FHD → HD → HEVC…).
                val cur = entries[index]
                if (altIdx < cur.alts.size) {
                    altIdx++
                    retries = 0
                    val resumeAt = if (live) 0L else lastGoodPosition
                    showText("Provo un'altra versione del canale… ($altIdx/${cur.alts.size})")
                    handler.postDelayed({ startCurrent(resumeAt, true) }, 400)
                    return
                }
                val unsupported = error.errorCode in 4000..4999
                val maxRetries = if (live) 3 else 2
                if (!unsupported && retries < maxRetries) {
                    retries++
                    val resumeAt = if (live) 0L else lastGoodPosition
                    showText("Riconnessione… ($retries/$maxRetries)")
                    handler.postDelayed({ startCurrent(resumeAt, true) }, 1500L * retries)
                } else {
                    val msg = if (unsupported)
                        "Il Firestick non riesce a decodificare questo video. Prova il lettore esterno dalle Impostazioni."
                    else
                        "Impossibile riprodurre: " + error.errorCodeName
                    Toast.makeText(this@PlayerActivity, msg, Toast.LENGTH_LONG).show()
                    finishWithResult()
                }
            }
        })

        startCurrent(p.optLong("startMs", 0L))
        handler.post(trackPosition)
    }

    /** Buffer: più ampio = meno interruzioni su connessioni instabili, ma avvio un po' più lento. */
    private fun loadControl(preset: String): LoadControl = when (preset) {
        "large" -> DefaultLoadControl.Builder()
            .setBufferDurationsMs(30_000, 120_000, 3_000, 8_000)
            .setTargetBufferBytes(64 * 1024 * 1024)
            .setPrioritizeTimeOverSizeThresholds(false)
            .build()
        "max" -> DefaultLoadControl.Builder()
            .setBufferDurationsMs(60_000, 240_000, 5_000, 15_000)
            .setTargetBufferBytes(100 * 1024 * 1024)
            .setPrioritizeTimeOverSizeThresholds(false)
            .build()
        else -> DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 50_000, 2_000, 4_000)
            .build()
    }

    private fun applyTrackPrefs(prefs: JSONObject) {
        val audio = prefs.optString("audioLang", "")
        val subs = prefs.optString("subLang", "off")
        val b = player.trackSelectionParameters.buildUpon()
        if (audio.isNotBlank()) b.setPreferredAudioLanguage(audio)
        if (subs.isBlank() || subs == "off") {
            // Nessun sottotitolo, tranne quelli "forzati" (es. dialoghi in lingua straniera).
            b.setPreferredTextLanguage(null)
            b.setIgnoredTextSelectionFlags(C.SELECTION_FLAG_FORCED.inv())
        } else {
            b.setPreferredTextLanguage(subs)
            b.setIgnoredTextSelectionFlags(0)
        }
        player.trackSelectionParameters = b.build()
    }

    private fun applySubtitleStyle(prefs: JSONObject) {
        val scale = when (prefs.optString("subSize", "m")) {
            "s" -> 0.8f
            "l" -> 1.3f
            "xl" -> 1.6f
            else -> 1f
        }
        val bg = if (prefs.optBoolean("subBg", false)) 0xB3000000.toInt() else Color.TRANSPARENT
        view.subtitleView?.let { sv ->
            sv.setFractionalTextSize(SubtitleView.DEFAULT_TEXT_SIZE_FRACTION * scale)
            sv.setStyle(
                CaptionStyleCompat(
                    Color.WHITE, bg, Color.TRANSPARENT,
                    CaptionStyleCompat.EDGE_TYPE_OUTLINE, Color.BLACK, Typeface.DEFAULT_BOLD
                )
            )
        }
    }

    private val trackPosition = object : Runnable {
        override fun run() {
            if (this@PlayerActivity::player.isInitialized && player.playbackState == Player.STATE_READY) {
                lastGoodPosition = player.currentPosition
            }
            handler.postDelayed(this, 2000)
        }
    }

    private fun parse(o: JSONObject) = Entry(
        url = o.optString("url", ""),
        title = o.optString("title", ""),
        subtitle = o.optString("subtitle", ""),
        key = o.optString("key", ""),
        mime = o.optString("mime", "").ifBlank { null },
        alts = o.optJSONArray("alts")?.let { a -> (0 until a.length()).map { a.optString(it) }.filter { it.isNotBlank() } } ?: emptyList()
    )

    private fun startCurrent(startMs: Long, keepAlt: Boolean = false) {
        currentRecorded = false
        if (!keepAlt) altIdx = 0
        val e = entries[index]
        val url = if (altIdx == 0) e.url else e.alts[altIdx - 1]
        val b = MediaItem.Builder()
            .setUri(url)
            .setMediaMetadata(MediaMetadata.Builder().setTitle(e.title).build())
        if (e.mime != null) b.setMimeType(e.mime)
        if (startMs > 0) player.setMediaItem(b.build(), startMs) else player.setMediaItem(b.build())
        player.prepare()
        player.playWhenReady = true
        showText(if (e.subtitle.isNotBlank()) e.title + "\n" + e.subtitle else e.title)
    }

    private fun showText(text: String) {
        info.text = text
        info.visibility = View.VISIBLE
        handler.removeCallbacks(hideInfo)
        handler.postDelayed(hideInfo, 4000)
    }

    private fun record(ended: Boolean) {
        if (currentRecorded) return
        currentRecorded = true
        val e = entries[index]
        val dur = player.duration
        updates.put(
            JSONObject()
                .put("key", e.key)
                .put("posMs", player.currentPosition)
                .put("durMs", if (dur == C.TIME_UNSET) 0L else dur)
                .put("ended", ended)
                .put("live", live)
        )
    }

    private fun zap(delta: Int) {
        if (entries.size < 2) return
        record(false)
        index = (index + delta + entries.size) % entries.size
        retries = 0
        startCurrent(0)
    }

    private fun seekBy(ms: Long) {
        val dur = player.duration
        var target = player.currentPosition + ms
        if (target < 0) target = 0
        if (dur != C.TIME_UNSET && target > dur - 1000) target = dur - 1000
        player.seekTo(target)
        val total = if (dur == C.TIME_UNSET) "" else " / " + fmt(dur)
        showText((if (ms > 0) "+" else "−") + (Math.abs(ms) / 1000) + " s   " + fmt(target) + total)
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(Locale.ROOT, "%d:%02d:%02d", h, m, sec)
        else String.format(Locale.ROOT, "%d:%02d", m, sec)
    }

    private fun finishWithResult() {
        if (finishing) return
        finishing = true
        if (this::player.isInitialized && entries.isNotEmpty()) record(false)
        setResult(RESULT_OK, Intent().putExtra("result", JSONObject().put("updates", updates).toString()))
        finish()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (!this::player.isInitialized) return super.dispatchKeyEvent(event)
        val controls = view.isControllerFullyVisible
        if (event.action == KeyEvent.ACTION_DOWN) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_BACK -> {
                    if (controls) view.hideController() else finishWithResult()
                    return true
                }
                KeyEvent.KEYCODE_CHANNEL_UP -> { zap(-1); return true }
                KeyEvent.KEYCODE_CHANNEL_DOWN -> { zap(1); return true }
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN -> {
                    if (live && !controls && entries.size > 1) {
                        zap(if (event.keyCode == KeyEvent.KEYCODE_DPAD_UP) -1 else 1)
                        return true
                    }
                }
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    if (!live && !controls) {
                        seekBy(if (event.keyCode == KeyEvent.KEYCODE_DPAD_LEFT) -10_000L else 10_000L)
                        return true
                    }
                }
                KeyEvent.KEYCODE_MEDIA_REWIND -> { if (!live) { seekBy(-30_000L); return true } }
                KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> { if (!live) { seekBy(30_000L); return true } }
                KeyEvent.KEYCODE_MENU -> {
                    resizeIdx = (resizeIdx + 1) % resizeModes.size
                    view.resizeMode = resizeModes[resizeIdx]
                    showText("Formato: " + resizeNames[resizeIdx])
                    return true
                }
            }
        } else if (event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_BACK) {
            return true
        }
        return view.dispatchKeyEvent(event) || super.dispatchKeyEvent(event)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    /** Su telefoni e tablet nasconde barra di stato e di navigazione (sul Firestick non cambia nulla). */
    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
    }

    override fun onStop() {
        super.onStop()
        if (this::player.isInitialized && !isFinishing) player.pause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (this::player.isInitialized) player.release()
        super.onDestroy()
    }
}
