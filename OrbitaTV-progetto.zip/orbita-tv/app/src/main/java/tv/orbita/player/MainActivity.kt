package tv.orbita.player

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Guscio dell'app: una WebView a schermo intero che mostra l'interfaccia (assets/www)
 * e un piccolo proxy HTTP nativo, così l'interfaccia può leggere server Xtream/M3U
 * in http senza i blocchi CORS del browser. La riproduzione passa a PlayerActivity.
 */
class MainActivity : Activity() {

    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.setBackgroundColor(0xFF0B1216.toInt())
        setContentView(web)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        s.textZoom = 100
        s.userAgentString = s.userAgentString + " OrbitaTV/" + BuildConfig.VERSION_NAME

        web.isFocusable = true
        web.isFocusableInTouchMode = true
        web.addJavascriptInterface(Bridge(), "OrbitaNative")
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val uri = request.url
                if (uri.host != HOST) return null
                return if (uri.path == "/proxy") proxy(uri) else asset(uri.path ?: "/")
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                request.url.host != HOST

            @Deprecated("Usato solo su Android 5.x")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean =
                Uri.parse(url).host != HOST
        }

        if (savedInstanceState != null) web.restoreState(savedInstanceState)
        else web.loadUrl("https://$HOST/index.html")
        web.requestFocus()
    }

    // ---------- file dell'interfaccia ----------

    private fun asset(path: String): WebResourceResponse {
        val clean = path.trimStart('/').ifEmpty { "index.html" }
        if (clean.contains("..")) return error(403, "Percorso non valido")
        return try {
            val ext = clean.substringAfterLast('.', "").lowercase()
            val mime = MIME[ext] ?: "application/octet-stream"
            val textual = mime.startsWith("text/") || mime.endsWith("javascript") || mime.endsWith("json")
            WebResourceResponse(mime, if (textual) "utf-8" else null, assets.open("www/$clean"))
        } catch (e: Exception) {
            error(404, "File non trovato: $clean")
        }
    }

    // ---------- proxy verso il server della playlist ----------

    private fun open(url: URL, ua: String): HttpURLConnection {
        val c = url.openConnection() as HttpURLConnection
        c.instanceFollowRedirects = false
        c.connectTimeout = 15000
        c.readTimeout = 90000
        c.setRequestProperty("User-Agent", ua)
        c.setRequestProperty("Accept", "*/*")
        return c
    }

    private fun proxy(uri: Uri): WebResourceResponse {
        val target = uri.getQueryParameter("u") ?: return error(400, "Indirizzo mancante")
        val ua = uri.getQueryParameter("ua")?.takeIf { it.isNotBlank() } ?: DEFAULT_UA
        return try {
            var url = URL(target)
            var conn = open(url, ua)
            var hops = 0
            // HttpURLConnection non segue i redirect http <-> https: li seguiamo a mano.
            while (conn.responseCode in 300..399 && hops < 6) {
                val loc = conn.getHeaderField("Location") ?: break
                conn.disconnect()
                url = URL(url, loc)
                conn = open(url, ua)
                hops++
            }
            var code = conn.responseCode
            if (code in 300..399 || code < 100 || code > 599) code = 502
            val stream = if (code >= 400) (conn.errorStream ?: ByteArrayInputStream(ByteArray(0))) else conn.inputStream
            // Filtro per file di testo enormi (es. la classifica Netflix di tutti i paesi):
            // restituisce solo l'intestazione e le righe che contengono il testo "grep".
            val grep = uri.getQueryParameter("grep")
            if (grep != null && code < 400) {
                val out = ByteArrayOutputStream()
                stream.bufferedReader(Charsets.UTF_8).useLines { lines ->
                    var first = true
                    lines.forEach { line ->
                        if (first || line.contains(grep)) {
                            out.write(line.toByteArray(Charsets.UTF_8))
                            out.write('\n'.code)
                        }
                        first = false
                    }
                }
                conn.disconnect()
                return WebResourceResponse(
                    "text/plain", "utf-8", 200, "OK",
                    mapOf("Access-Control-Allow-Origin" to "*", "Cache-Control" to "no-store"),
                    ByteArrayInputStream(out.toByteArray())
                )
            }
            val ct = conn.contentType ?: "application/octet-stream"
            val mime = ct.substringBefore(';').trim().ifEmpty { "application/octet-stream" }
            val charset = Regex("charset=([^;]+)", RegexOption.IGNORE_CASE).find(ct)?.groupValues?.get(1)?.trim()
            val reason = conn.responseMessage?.takeIf { it.isNotBlank() } ?: if (code < 400) "OK" else "Error"
            WebResourceResponse(
                mime, charset, code, reason,
                mapOf(
                    "Access-Control-Allow-Origin" to "*",
                    "Cache-Control" to "no-store",
                    "X-Final-Url" to url.toString()
                ),
                stream
            )
        } catch (e: Exception) {
            error(502, e.javaClass.simpleName + ": " + (e.message ?: "connessione non riuscita"))
        }
    }

    private fun error(code: Int, msg: String) = WebResourceResponse(
        "text/plain", "utf-8", code, "Error",
        mapOf("Access-Control-Allow-Origin" to "*"),
        ByteArrayInputStream(msg.toByteArray())
    )

    // ---------- ponte JavaScript ----------

    inner class Bridge {
        @JavascriptInterface
        fun play(payload: String) {
            runOnUiThread {
                val i = Intent(this@MainActivity, PlayerActivity::class.java)
                i.putExtra("payload", payload)
                @Suppress("DEPRECATION")
                startActivityForResult(i, REQ_PLAY)
            }
        }

        /** Apre il flusso in un lettore esterno installato (VLC, MX Player, …). */
        @JavascriptInterface
        fun openExternal(payload: String) {
            runOnUiThread {
                try {
                    val o = JSONObject(payload)
                    val i = Intent(Intent.ACTION_VIEW)
                    i.setDataAndType(Uri.parse(o.optString("url")), o.optString("mime").ifBlank { "video/*" })
                    i.putExtra("title", o.optString("title"))
                    startActivity(Intent.createChooser(i, "Apri con"))
                } catch (e: Exception) {
                    val msg = JSONObject.quote("Nessun lettore esterno trovato: installa per esempio VLC dall'Appstore.")
                    web.evaluateJavascript("window.orbitaToast && window.orbitaToast($msg)", null)
                }
            }
        }

        @JavascriptInterface
        fun exitApp() {
            runOnUiThread { finish() }
        }

        @JavascriptInterface
        fun version(): String = BuildConfig.VERSION_NAME
    }

    @Deprecated("API classica, sufficiente su Fire OS")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PLAY) return
        val result = data?.getStringExtra("result") ?: return
        web.evaluateJavascript(
            "window.onNativePlaybackEnded && window.onNativePlaybackEnded(${JSONObject.quote(result)})",
            null
        )
    }

    @Deprecated("Il tasto Indietro viene prima offerto all'interfaccia")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.orbitaBack && window.orbitaBack()) ? 'handled' : 'exit'") { r ->
            if (r == null || !r.contains("handled")) finish()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onPause() {
        super.onPause()
        web.onPause()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        web.requestFocus()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }

    companion object {
        const val HOST = "appassets.androidplatform.net"
        const val DEFAULT_UA = "OrbitaTV/1.0 (Linux; Android)"
        private const val REQ_PLAY = 42
        private val MIME = mapOf(
            "html" to "text/html",
            "js" to "application/javascript",
            "css" to "text/css",
            "json" to "application/json",
            "svg" to "image/svg+xml",
            "png" to "image/png",
            "jpg" to "image/jpeg",
            "webp" to "image/webp",
            "woff2" to "font/woff2"
        )
    }
}
