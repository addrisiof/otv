
(function () {
'use strict';

var NATIVE = typeof window.OrbitaNative !== 'undefined';
var CAT_V = 3;
var $ = function (s, r) { return (r || document).querySelector(s); };
var stage = $('#stage');

/* ================= utilities ================= */
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function num(v) { var n = parseFloat(v); return isFinite(n) ? n : 0; }
function hash(s) { var h = 5381; s = String(s); for (var i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return (h >>> 0).toString(36); }
function norm(s) { s = String(s || '').toLowerCase(); try { s = s.normalize('NFD').replace(/[\u0300-\u036f]/g, ''); } catch (e) {} return s; }
function arr(a) { if (Array.isArray(a)) return a; if (a && typeof a === 'object') return Object.keys(a).map(function (k) { return a[k]; }); return []; }
function pad2(n) { return (n < 10 ? '0' : '') + n; }
function hhmm(t) { var d = new Date(t); return pad2(d.getHours()) + ':' + pad2(d.getMinutes()); }
function fmtRating(r) { return (Math.round(r * 10) / 10).toFixed(1).replace('.', ','); }
function fmtDur(sec) { sec = Math.round(sec); if (!sec) return ''; var h = Math.floor(sec / 3600), m = Math.round((sec % 3600) / 60); return h ? h + ' h ' + pad2(m) + ' min' : m + ' min'; }
function fmtClock(ms) { var s = Math.floor(ms / 1000), h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60; return (h ? h + ':' + pad2(m) : m) + ':' + pad2(x); }
function durToSecs(d) { if (!d) return 0; var p = String(d).split(':').map(num); if (p.length === 3) return p[0] * 3600 + p[1] * 60 + p[2]; if (p.length === 2) return p[0] * 60 + p[1]; return num(d) * 60; }
function ratingOf(s) { var r = num(s.rating); if (!r && s.rating_5based) r = num(s.rating_5based) * 2; if (r > 10) r = r / 10; return r > 0 ? Math.round(r * 10) / 10 : 0; }
function yearOf(s, name) { var y = String(s.year || s.releaseDate || s.release_date || s.releasedate || ''); var m = y.match(/(19|20)\d{2}/) || String(name || '').match(/\((19|20)\d{2}\)/); return m ? m[0].replace(/[()]/g, '') : ''; }
function dispName(n) { return String(n || '').replace(/^\s*[\[(|]?[A-Z]{2,4}[\])|]?\s*[-:|]\s+/, '').replace(/\s*\[[^\]]*\]\s*/g, ' ').replace(/\s+/g, ' ').trim() || String(n || ''); }
function cleanTitle(n) { return String(n || '').replace(/\s*\((19|20)\d{2}\)\s*$/, '').trim(); }
function firstImg(b) { if (Array.isArray(b)) return b[0] || ''; return typeof b === 'string' ? b : ''; }
function b64(s) { if (!s) return ''; try { var bin = atob(s); var u = new Uint8Array(bin.length); for (var i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return new TextDecoder('utf-8').decode(u); } catch (e) { return String(s); } }
function xmlDec(s) { return String(s || '').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1').replace(/&#(\d+);/g, function (m, d) { return String.fromCharCode(+d); }).replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&').trim(); }
function debounce(fn, ms) { var t; return function () { var a = arguments, c = this; clearTimeout(t); t = setTimeout(function () { fn.apply(c, a); }, ms); }; }

var LS = {
  get: function (k, d) { try { var v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
  set: function (k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
};

var IDB = (function () {
  var dbp = null;
  function db() {
    if (!dbp) dbp = new Promise(function (res, rej) {
      var q = indexedDB.open('orbita', 1);
      q.onupgradeneeded = function () { q.result.createObjectStore('kv'); };
      q.onsuccess = function () { res(q.result); };
      q.onerror = function () { rej(q.error); };
    });
    return dbp;
  }
  function get(k) { return db().then(function (d) { return new Promise(function (res) { var r = d.transaction('kv', 'readonly').objectStore('kv').get(k); r.onsuccess = function () { res(r.result); }; r.onerror = function () { res(undefined); }; }); }).catch(function () { return undefined; }); }
  function set(k, v) { return db().then(function (d) { return new Promise(function (res) { var tx = d.transaction('kv', 'readwrite'); tx.objectStore('kv').put(v, k); tx.oncomplete = function () { res(true); }; tx.onerror = function () { res(false); }; }); }).catch(function () { return false; }); }
  return { get: get, set: set };
})();

/* ================= icons ================= */
var IC = {
  play: '<svg viewBox="0 0 24 24"><path d="M7 4.5l13 7.5-13 7.5z" fill="currentColor"/></svg>',
  plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>',
  check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7"/></svg>',
  info: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/></svg>',
  restart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12a8 8 0 1 0 2.5-5.8M4 4v4.5h4.5"/></svg>',
  arrow: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>',
  star: '<svg viewBox="0 0 24 24"><path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z" fill="currentColor"/></svg>',
  starO: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z"/></svg>'
};

/* ================= generated artwork (fallbacks and demo) ================= */
function svgUri(svg) { return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg); }
function hueOf(s) { return parseInt(hash(s), 36) % 360; }
function artPoster(title, hue, motif, wide) {
  var W = wide ? 640 : 300, H = wide ? 360 : 450, h2 = (hue + 38) % 360, cx = W * 0.64, cy = H * (wide ? 0.4 : 0.34), m = '', i;
  var bg = '<defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="hsl(' + hue + ',42%,30%)"/><stop offset="1" stop-color="hsl(' + h2 + ',48%,8%)"/></linearGradient></defs><rect width="' + W + '" height="' + H + '" fill="url(#g)"/>';
  if (motif === 0) m = '<circle cx="' + cx + '" cy="' + cy + '" r="' + (W * (wide ? 0.13 : 0.22)) + '" fill="hsl(' + ((hue + 170) % 360) + ',65%,72%)" opacity=".85"/>';
  else if (motif === 1) { for (i = 0; i < 7; i++) m += '<rect x="0" y="' + (H * 0.44 + i * H * 0.045) + '" width="' + W + '" height="' + (H * 0.012) + '" fill="hsl(' + h2 + ',60%,75%)" opacity="' + (0.55 - i * 0.07).toFixed(2) + '"/>'; }
  else if (motif === 2) m = '<ellipse cx="' + cx + '" cy="' + cy + '" rx="' + (W * (wide ? 0.2 : 0.32)) + '" ry="' + (W * (wide ? 0.07 : 0.11)) + '" fill="none" stroke="hsl(38,75%,66%)" stroke-width="3" transform="rotate(-18 ' + cx + ' ' + cy + ')"/><circle cx="' + cx + '" cy="' + cy + '" r="' + (W * (wide ? 0.07 : 0.12)) + '" fill="hsl(' + hue + ',35%,58%)"/>';
  else m = '<path d="M0 ' + (H * 0.64) + ' L' + (W * 0.3) + ' ' + (H * 0.42) + ' L' + (W * 0.55) + ' ' + (H * 0.56) + ' L' + (W * 0.8) + ' ' + (H * 0.3) + ' L' + W + ' ' + (H * 0.5) + ' V' + H + ' H0Z" fill="hsl(' + h2 + ',35%,15%)"/>';
  var words = String(title).split(' '), lines = [], cur = '', maxc = wide ? 22 : 12;
  words.forEach(function (w) { if ((cur + ' ' + w).trim().length > maxc && cur) { lines.push(cur); cur = w; } else cur = (cur + ' ' + w).trim(); });
  if (cur) lines.push(cur);
  lines = lines.slice(0, 4);
  var fs = 30, y0 = H - 32 - (lines.length - 1) * fs * 1.04;
  var tx = wide ? '' : lines.map(function (l, k) { return '<text x="' + (wide ? 34 : 22) + '" y="' + (y0 + k * fs * 1.04).toFixed(1) + '" font-family="Bricolage Grotesque,Trebuchet MS,sans-serif" font-weight="800" font-size="' + fs + '" fill="#f2ede4">' + esc(l) + '</text>'; }).join('');
  return svgUri('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + W + ' ' + H + '" width="' + W + '" height="' + H + '">' + bg + m + tx + '</svg>');
}
function artLogo(name) {
  var hue = hueOf(name), ab = String(name).replace(/[^A-Za-z0-9À-ÿ ]/g, '').split(' ').filter(Boolean).map(function (w) { return /^\d+$/.test(w) ? w : w[0]; }).join('').slice(0, 3).toUpperCase();
  return svgUri('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 180" width="320" height="180"><rect x="40" y="30" width="240" height="120" rx="26" fill="hsl(' + hue + ',45%,22%)"/><rect x="40" y="30" width="240" height="120" rx="26" fill="none" stroke="hsl(' + hue + ',55%,55%)" stroke-width="4"/><text x="160" y="110" text-anchor="middle" font-family="Bricolage Grotesque,Trebuchet MS,sans-serif" font-weight="800" font-size="62" fill="#f2ede4">' + esc(ab || 'TV') + '</text></svg>');
}
var fbCache = {};
function fallbackFor(alt, kind) {
  var k = kind + '|' + alt;
  if (!fbCache[k]) fbCache[k] = kind === 'logo' ? artLogo(alt || 'TV') : artPoster(alt || 'Senza titolo', hueOf(alt), parseInt(hash(alt), 36) % 4, kind === 'wide');
  return fbCache[k];
}
document.addEventListener('error', function (e) {
  var t = e.target;
  if (t && t.tagName === 'IMG' && !t.__fb) { t.__fb = 1; t.src = fallbackFor(t.alt, t.getAttribute('data-fb') || 'poster'); }
}, true);
function img(src, alt, kind, cls) {
  var s = src || fallbackFor(alt, kind || 'poster');
  return '<img' + (cls ? ' class="' + cls + '"' : '') + ' alt="' + esc(alt) + '" data-fb="' + (kind || 'poster') + '" loading="lazy" decoding="async" src="' + esc(s) + '">';
}

/* ================= state ================= */
var S = {
  view: 'home',
  sources: LS.get('orbita.sources', []),
  activeId: LS.get('orbita.active', null),
  settings: Object.assign({ liveFormat: 'ts', hideAdult: true, ua: '', buffer: 'standard', audioLang: 'it', subLang: 'off', subSize: 'm', subBg: false, player: 'internal', startLast: false, pin: '', tmdbKey: '', omdbKey: '', preferTmdb: false }, LS.get('orbita.settings', {})),
  user: null, D: null, V: null, idx: {}, pending: {}, overlay: null,
  hero: [], heroIdx: 0, heroTimer: null,
  grid: { movie: { cat: '__all', sort: 'recent', list: [], shown: 0 }, series: { cat: '__all', sort: 'recent', list: [], shown: 0 } },
  live: { cat: '__all', list: [], shown: 0, sel: null, mode: 'list' },
  modal: null, charts: null, chartsBusy: false, mindex: null, booted: false, guideShown: 0, catsKind: 'live',
  epg: {}, form: null, lastContent: null, exitArmed: false, query: '', shelves: [], io: null
};
function src() { for (var i = 0; i < S.sources.length; i++) if (S.sources[i].id === S.activeId) return S.sources[i]; return null; }
function saveSources() { LS.set('orbita.sources', S.sources); LS.set('orbita.active', S.activeId); }
function saveSettings() { LS.set('orbita.settings', S.settings); }
function loadUser() { S.user = Object.assign({ fav: {}, prog: {}, plays: {}, watched: {}, lastEp: {}, hidden: { movie: {}, series: {}, live: {} }, lastCh: null }, LS.get('orbita.user.' + S.activeId, {})); }
function saveUser() { LS.set('orbita.user.' + S.activeId, S.user); }

/* ================= network ================= */
function http(url) {
  var u = NATIVE ? '/proxy?u=' + encodeURIComponent(url) + (S.settings.ua ? '&ua=' + encodeURIComponent(S.settings.ua) : '') : url;
  return fetch(u, { cache: 'no-store' }).then(function (r) {
    if (!r.ok) return r.text().catch(function () { return ''; }).then(function (t) { throw new Error('Il server ha risposto con errore ' + r.status + (t ? ' (' + t.slice(0, 120) + ')' : '') + '.'); });
    return r;
  }, function (err) {
    throw new Error(NATIVE ? 'Server non raggiungibile: ' + err.message : 'Nell’anteprima web il browser blocca la connessione diretta ai server IPTV. Nell’app installata sul Firestick la connessione funziona.');
  });
}
function parseServer(input) {
  var s = String(input || '').trim(), out = { server: '' };
  if (!s) return out;
  if (!/^https?:\/\//i.test(s)) s = 'http://' + s;
  try {
    var u = new URL(s);
    if (u.searchParams.get('username')) out.user = u.searchParams.get('username');
    if (u.searchParams.get('password')) out.pass = u.searchParams.get('password');
    var path = u.pathname.replace(/\/(player_api|get|xmltv)\.php$/i, '').replace(/\/+$/, '');
    out.server = u.protocol + '//' + u.host + path;
  } catch (e) { out.server = s.replace(/\/+$/, ''); }
  return out;
}
function xapi(s, action, params) {
  var q = 'username=' + encodeURIComponent(s.user) + '&password=' + encodeURIComponent(s.pass) + (action ? '&action=' + action : '');
  if (params) Object.keys(params).forEach(function (k) { q += '&' + k + '=' + encodeURIComponent(params[k]); });
  return http(s.server + '/player_api.php?' + q).then(function (r) { return r.text(); }).then(function (t) {
    try { return JSON.parse(t); } catch (e) { throw new Error('Il server non ha restituito dati validi. Controlla l’indirizzo del server.'); }
  });
}

/* ================= Xtream Codes ================= */
function loadXtream(s, step) {
  var D = { movie: [], series: [], live: [], cats: { movie: [], series: [], live: [] }, account: null };
  step('Accesso al server…');
  return xapi(s, '').then(function (a) {
    if (!a || !a.user_info) throw new Error('Il server non ha riconosciuto l’account. Controlla server, nome utente e password.');
    if (String(a.user_info.auth) === '0') throw new Error('Nome utente o password non validi.');
    var u = a.user_info;
    D.account = { status: u.status || '', exp: u.exp_date || '', active: u.active_cons, max: u.max_connections, trial: u.is_trial };
    step('Categorie…');
    return Promise.all([xapi(s, 'get_vod_categories'), xapi(s, 'get_series_categories'), xapi(s, 'get_live_categories')]);
  }).then(function (c) {
    D.cats.movie = xcats(c[0]); D.cats.series = xcats(c[1]); D.cats.live = xcats(c[2]);
    step('Film…'); return xapi(s, 'get_vod_streams');
  }).then(function (a) {
    D.movie = arr(a).map(function (m) { return { key: 'm' + m.stream_id, kind: 'movie', id: m.stream_id, name: cleanTitle(m.name), poster: m.stream_icon || '', rating: ratingOf(m), added: num(m.added), year: yearOf(m, m.name), cat: String(m.category_id), ext: m.container_extension || 'mp4' }; });
    step('Serie TV…'); return xapi(s, 'get_series');
  }).then(function (a) {
    D.series = arr(a).map(function (x) { return { key: 's' + x.series_id, kind: 'series', id: x.series_id, name: cleanTitle(x.name), poster: x.cover || '', backdrop: firstImg(x.backdrop_path), plot: x.plot || '', genre: x.genre || '', cast: x.cast || '', director: x.director || '', rating: ratingOf(x), added: num(x.last_modified), year: yearOf(x, x.name), cat: String(x.category_id) }; });
    step('Canali in diretta…'); return xapi(s, 'get_live_streams');
  }).then(function (a) {
    D.live = arr(a).map(function (l) { return { key: 'l' + l.stream_id, kind: 'live', id: l.stream_id, name: String(l.name || '').trim(), poster: l.stream_icon || '', num: num(l.num), cat: String(l.category_id), epgId: l.epg_channel_id || '', archive: num(l.tv_archive), archiveDays: num(l.tv_archive_duration) }; });
    return D;
  });
}
function xcats(a) { return arr(a).map(function (c) { return { id: String(c.category_id), name: String(c.category_name || 'Senza nome') }; }); }
function xMovieInfo(it, d) {
  var i = (d && d.info) || {};
  it.plot = i.plot || i.description || it.plot || '';
  it.cast = i.cast || i.actors || ''; it.director = i.director || ''; it.genre = i.genre || '';
  it.dur = num(i.duration_secs) || durToSecs(i.duration);
  it.backdrop = firstImg(i.backdrop_path) || it.backdrop || '';
  if (!it.rating) it.rating = ratingOf(i);
  if (!it.year) it.year = yearOf(i, '');
  if (!it.poster) it.poster = i.movie_image || '';
  if (d && d.movie_data && d.movie_data.container_extension) it.ext = d.movie_data.container_extension;
  if (!it.tmdbId && num(i.tmdb_id || i.tmdb)) it.tmdbId = num(i.tmdb_id || i.tmdb);
}
function xSeriesInfo(it, d) {
  var i = (d && d.info) || {}, eps = d && d.episodes, seasons = [];
  if (eps) Object.keys(eps).forEach(function (sk) {
    var list = arr(eps[sk]).map(function (e) {
      var inf = e.info || {};
      var t = String(e.title || ''); var m = t.match(/S\d{1,2}\s*E\d{1,3}\s*[-–:.]?\s*(.*)$/i); if (m) t = m[1];
      return { id: e.id, key: 'e' + e.id, num: num(e.episode_num), title: t.trim(), ext: e.container_extension || 'mp4', plot: inf.plot || '', dur: num(inf.duration_secs) || durToSecs(inf.duration), thumb: inf.movie_image || '' };
    }).sort(function (a, b) { return a.num - b.num; });
    seasons.push({ n: num(sk), eps: list });
  });
  seasons.sort(function (a, b) { return a.n - b.n; });
  it.plot = i.plot || it.plot || ''; it.cast = i.cast || it.cast || ''; it.director = i.director || it.director || ''; it.genre = i.genre || it.genre || '';
  if (!it.backdrop) it.backdrop = firstImg(i.backdrop_path);
  if (!it.rating) it.rating = ratingOf(i);
  if (!it.year) it.year = yearOf(i, '');
  it.seasonList = seasons;
  if (!it.tmdbId && num(i.tmdb_id || i.tmdb)) it.tmdbId = num(i.tmdb_id || i.tmdb);
}

/* ================= M3U ================= */
function classify(url, name, group) {
  var u = url.toLowerCase().split('?')[0];
  if (u.indexOf('/series/') >= 0) return 'episode';
  if (u.indexOf('/movie/') >= 0) return 'movie';
  var hasEp = /S\d{1,2}\s*[._-]?\s*E\d{1,3}/i.test(name);
  if (/\.(mp4|mkv|avi|mov|m4v|webm|wmv|flv)$/.test(u)) return hasEp ? 'episode' : 'movie';
  if (hasEp && /seri|show|stagion|episod/i.test(group)) return 'episode';
  if (/(^|[^a-z])(vod|film|films|movie|movies|cinema)([^a-z]|$)/i.test(group)) return 'movie';
  return 'live';
}
function epInfo(name) {
  var m = String(name).match(/^(.*?)[\s._\-|]*S(\d{1,2})\s*[._-]?\s*E(\d{1,3})\s*[-–:.]?\s*(.*)$/i);
  if (!m) return { show: name, season: 1, ep: 0, title: name };
  return { show: (m[1] || name).trim(), season: +m[2], ep: +m[3], title: (m[4] || '').trim() };
}
function parseM3U(text) {
  var lines = text.split(/\r?\n/), D = { movie: [], series: [], live: [], cats: { movie: [], series: [], live: [] }, epgUrl: '' };
  var seen = { movie: {}, series: {}, live: {} }, smap = {}, cur = null, grp = '';
  function addCat(k, n) { if (!seen[k][n]) { seen[k][n] = 1; D.cats[k].push({ id: n, name: n }); } }
  for (var i = 0; i < lines.length; i++) {
    var L = lines[i].trim();
    if (!L) continue;
    if (L.charAt(0) === '#') {
      if (/^#EXTM3U/i.test(L)) { var mm = L.match(/(?:url-tvg|x-tvg-url)="([^"]+)"/i); if (mm) D.epgUrl = mm[1].split(',')[0].trim(); }
      else if (/^#EXTINF/i.test(L)) {
        cur = { attrs: {} }; grp = '';
        var re = /([\w-]+)="([^"]*)"/g, a;
        while ((a = re.exec(L))) cur.attrs[a[1].toLowerCase()] = a[2];
        var lq = L.lastIndexOf('"'), ci = L.indexOf(',', lq > 0 ? lq : 0);
        cur.name = (ci >= 0 ? L.slice(ci + 1) : '').trim();
      } else if (/^#EXTGRP:/i.test(L)) grp = L.slice(8).trim();
      continue;
    }
    if (!cur) continue;
    var at = cur.attrs, name = cur.name || at['tvg-name'] || 'Senza titolo', group = at['group-title'] || grp || 'Altro', h = hash(L), kind = classify(L, name, group);
    if (kind === 'live') { addCat('live', group); D.live.push({ key: 'l' + h, kind: 'live', id: h, name: name, poster: at['tvg-logo'] || '', num: D.live.length + 1, cat: group, epgId: at['tvg-id'] || '', url: L }); }
    else if (kind === 'movie') { addCat('movie', group); D.movie.push({ key: 'm' + h, kind: 'movie', id: h, name: cleanTitle(name), poster: at['tvg-logo'] || '', rating: 0, added: 0, year: yearOf({}, name), cat: group, url: L }); }
    else {
      var ep = epInfo(name), sk = norm(ep.show) + '|' + group, se = smap[sk];
      if (!se) { se = smap[sk] = { key: 's' + hash(sk), kind: 'series', id: hash(sk), name: cleanTitle(ep.show), poster: at['tvg-logo'] || '', rating: 0, added: 0, year: yearOf({}, ep.show), cat: group, plot: '', seasons: {} }; D.series.push(se); addCat('series', group); }
      (se.seasons[ep.season] = se.seasons[ep.season] || []).push({ id: h, key: 'e' + h, num: ep.ep, title: ep.title, url: L, thumb: '' });
    }
    cur = null;
  }
  D.series.forEach(function (se) {
    se.seasonList = Object.keys(se.seasons).map(Number).sort(function (a, b) { return a - b; }).map(function (k) {
      var eps = se.seasons[k].sort(function (a, b) { return a.num - b.num; });
      eps.forEach(function (e, j) { if (!e.num) e.num = j + 1; });
      return { n: k, eps: eps };
    });
    delete se.seasons;
  });
  return D;
}
function loadM3U(s, step) {
  step('Scarico la playlist…');
  return http(s.m3u).then(function (r) { return r.text(); }).then(function (t) {
    if (t.indexOf('#EXTINF') < 0) throw new Error('Il link non contiene una playlist M3U valida.');
    step('Leggo la playlist…');
    var D = parseM3U(t);
    if (s.epg) D.epgUrl = s.epg;
    return D;
  });
}

/* ================= EPG ================= */
var xmltvP = null;
function xtvDate(s) {
  var m = String(s || '').match(/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})?\s*([+-]\d{4})?/);
  if (!m) return 0;
  var t = Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +(m[6] || 0));
  if (m[7]) { var sg = m[7].charAt(0) === '-' ? -1 : 1; t -= sg * (+m[7].slice(1, 3) * 60 + +m[7].slice(3, 5)) * 60000; }
  return t;
}
function parseXmltv(t, want) {
  var map = {}, now = Date.now(), lim = now + 18 * 3600e3, re = /<programme\b([^>]*)>([\s\S]*?)<\/programme>/g, m;
  while ((m = re.exec(t))) {
    var a = m[1], ch = (a.match(/channel="([^"]*)"/) || [])[1];
    if (!ch) continue; ch = ch.toLowerCase();
    if (!want[ch]) continue;
    var st = xtvDate((a.match(/start="([^"]*)"/) || [])[1]), en = xtvDate((a.match(/stop="([^"]*)"/) || [])[1]);
    if (!st || !en || en < now || st > lim) continue;
    (map[ch] = map[ch] || []).push({ t: xmlDec((m[2].match(/<title[^>]*>([\s\S]*?)<\/title>/) || [])[1]), d: xmlDec((m[2].match(/<desc[^>]*>([\s\S]*?)<\/desc>/) || [])[1]), s: st, e: en });
  }
  return map;
}
function loadXmltv() {
  if (xmltvP) return xmltvP;
  var s = src(), url = (s && s.epg) || (S.D && S.D.epgUrl);
  if (!url) return Promise.resolve(null);
  var want = {};
  S.V.live.forEach(function (c) { if (c.epgId) want[c.epgId.toLowerCase()] = 1; });
  xmltvP = http(url).then(function (r) {
    if (/\.gz(\?|$)/i.test(url) && typeof DecompressionStream !== 'undefined' && r.body) return new Response(r.body.pipeThrough(new DecompressionStream('gzip'))).text();
    return r.text();
  }).then(function (t) { return parseXmltv(t, want); }).catch(function () { xmltvP = null; return null; });
  return xmltvP;
}
function getEpg(it) {
  var c = S.epg[it.key];
  if (c && Date.now() - c.ts < 10 * 60 * 1000) return Promise.resolve(c.list);
  var s = src(), p;
  if (s.type === 'demo') p = Promise.resolve(demoEpg(it));
  else if (s.type === 'xtream') p = xapi(s, 'get_short_epg', { stream_id: it.id, limit: 6 }).then(function (d) {
    return arr(d && d.epg_listings).map(function (e) { return { t: b64(e.title), d: b64(e.description), s: num(e.start_timestamp) * 1000 || Date.parse(e.start), e: num(e.stop_timestamp) * 1000 || Date.parse(e.end) }; });
  });
  else p = loadXmltv().then(function (map) { return (map && it.epgId && map[it.epgId.toLowerCase()]) || []; });
  return p.then(function (list) {
    var now = Date.now();
    list = list.filter(function (x) { return x.e > now; }).sort(function (a, b) { return a.s - b.s; });
    S.epg[it.key] = { ts: Date.now(), list: list };
    return list;
  }).catch(function () { return []; });
}

/* ================= demo catalogue ================= */
function rng(seed) { return function () { seed |= 0; seed = seed + 0x6D2B79F5 | 0; var t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
function demoCatalog() {
  var R = rng(20261112), pick = function (a) { return a[Math.floor(R() * a.length)]; }, now = Math.floor(Date.now() / 1000);
  var A = ['Il faro di', 'Ombre su', 'L’ultima estate a', 'Il silenzio di', 'Notte a', 'Il segreto di', 'Ritorno a', 'Vento su', 'Le luci di', 'Il ponte di', 'Lettere da', 'La rotta per', 'Il custode di', 'Tre giorni a'];
  var B = ['Polignano', 'Matera', 'Trieste', 'Otranto', 'Bari Vecchia', 'Lampedusa', 'Gargano', 'Alberobello', 'Procida', 'Torino', 'Murano', 'Ostuni', 'Capo Nord', 'Lisbona', 'Kyoto', 'Taranto'];
  var SOLO = ['Frequenza zero', 'Il nono pianeta', 'Carta carbone', 'Mezzanotte esatta', 'Stanza 214', 'Codice Ionio', 'Bassa marea', 'Il suono del sale', 'Orbita bassa', 'Gli insonni', 'Linea di galleggiamento', 'Segnale debole'];
  var P1 = ['Un restauratore di barche', 'Una giornalista precaria', 'Due fratelli che non si parlano da anni', 'Un’ingegnera del vento', 'Il vecchio guardiano del faro', 'Una band di paese', 'Una pilota di elicotteri', 'Un cuoco senza ristorante', 'Una cartografa ostinata'];
  var P2 = ['torna a casa per l’estate', 'trova una lettera mai spedita', 'eredita una masseria in rovina', 'accetta un ultimo lavoro', 'segue un segnale radio misterioso', 'deve consegnare un pacco entro l’alba', 'riapre un caso chiuso da vent’anni'];
  var P3 = ['e niente va come previsto.', 'mentre il paese si prepara alla festa patronale.', 'finché il mare non restituisce un segreto.', 'con una tempesta in arrivo dall’Adriatico.', 'e una vecchia promessa torna a galla.'];
  var NAMES = ['Giulia Ferrante', 'Marco Lisi', 'Anna De Palo', 'Luca Montrone', 'Sara Caputo', 'Davide Ranieri', 'Elena Volpe', 'Nicola Sgobba', 'Irene Laterza', 'Paolo Amoruso', 'Chiara Dibenedetto', 'Tommaso Ricci'];
  var GEN = ['Drammatico', 'Commedia', 'Thriller', 'Avventura', 'Fantascienza', 'Giallo', 'Documentario', 'Animazione'];
  var EPT = ['Pilota', 'La partenza', 'Acqua alta', 'Il testimone', 'Fuori rotta', 'Linea d’ombra', 'Il patto', 'Controcorrente', 'Notte bianca', 'Ritorno', 'La mappa', 'Bonaccia', 'Il faro spento', 'Ultima chiamata'];
  var mcats = ['Prime visioni', 'Drammatici', 'Commedie italiane', 'Thriller e gialli', 'Animazione', 'Documentari', 'Fantascienza', 'Avventura'];
  var scats = ['Serie italiane', 'Crime', 'Fantascienza', 'Miniserie'];
  var lcats = ['Generalisti', 'Notizie', 'Sport', 'Bambini', 'Musica', 'Documentari'];
  var used = {};
  function title() { for (var k = 0; k < 30; k++) { var t = R() < 0.25 ? pick(SOLO) : pick(A) + ' ' + pick(B); if (!used[t]) { used[t] = 1; return t; } } return pick(A) + ' ' + pick(B) + ' 2'; }
  function plot() { return pick(P1) + ' ' + pick(P2) + ' ' + pick(P3); }
  function cast() { var c = []; for (var k = 0; k < 3; k++) { var n = pick(NAMES); if (c.indexOf(n) < 0) c.push(n); } return c.join(', '); }
  var D = { movie: [], series: [], live: [], cats: { movie: [], series: [], live: [] }, account: { status: 'Active', exp: String(now + 86400 * 143), active: '0', max: '2' }, epgUrl: '' };
  mcats.forEach(function (n, i) { D.cats.movie.push({ id: 'dm' + i, name: n }); });
  scats.forEach(function (n, i) { D.cats.series.push({ id: 'ds' + i, name: n }); });
  lcats.forEach(function (n, i) { D.cats.live.push({ id: 'dl' + i, name: n }); });
  var i, t, hue;
  for (i = 0; i < 88; i++) {
    t = title(); hue = Math.floor(R() * 360);
    D.movie.push({ key: 'mdemo' + i, kind: 'movie', id: 'm' + i, name: t, poster: artPoster(t, hue, i % 4), backdrop: artPoster(t, hue, i % 4, true), rating: Math.round((5.2 + R() * 3.7) * 10) / 10, added: now - Math.floor(R() * 86400 * 150), year: String(2012 + Math.floor(R() * 15)), cat: 'dm' + Math.floor(R() * mcats.length), plot: plot(), genre: pick(GEN), cast: cast(), director: pick(NAMES), dur: (82 + Math.floor(R() * 70)) * 60, url: 'demo://movie/' + i });
  }
  for (i = 0; i < 26; i++) {
    t = title(); hue = Math.floor(R() * 360);
    var ns = 1 + Math.floor(R() * 3), seasons = [];
    for (var sn = 1; sn <= ns; sn++) {
      var ne = 6 + Math.floor(R() * 5), eps = [];
      for (var en = 1; en <= ne; en++) eps.push({ id: 'd' + i + '_' + sn + '_' + en, key: 'edemo' + i + '_' + sn + '_' + en, num: en, title: pick(EPT), plot: plot(), dur: (38 + Math.floor(R() * 20)) * 60, thumb: '', url: 'demo://ep/' + i + '/' + sn + '/' + en });
      seasons.push({ n: sn, eps: eps });
    }
    D.series.push({ key: 'sdemo' + i, kind: 'series', id: 's' + i, name: t, poster: artPoster(t, hue, (i + 1) % 4), backdrop: artPoster(t, hue, (i + 1) % 4, true), rating: Math.round((5.8 + R() * 3.2) * 10) / 10, added: now - Math.floor(R() * 86400 * 150), year: String(2015 + Math.floor(R() * 12)), cat: 'ds' + Math.floor(R() * scats.length), plot: plot(), genre: pick(GEN), cast: cast(), director: pick(NAMES), seasonList: seasons });
  }
  var CH = [['Orbita Uno', 0], ['Orbita Due', 0], ['Canale Faro', 0], ['Ionio TV', 0], ['Rete Levante', 0], ['Notizie Ora', 1], ['Meteo Mare', 1], ['Agorà 24', 1], ['Sport Arena 1', 2], ['Sport Arena 2', 2], ['Motori Live', 2], ['Pallavolo Plus', 2], ['Cartoni Blu', 3], ['Piccoli Esploratori', 3], ['Ritmo TV', 4], ['Vinile Channel', 4], ['Live Club', 4], ['Pianeta Doc', 5], ['Storia Viva', 5], ['Natura Selvaggia', 5], ['Cucina & Co', 0], ['Cinema Classico', 0]];
  CH.forEach(function (c, k) { D.live.push({ key: 'ldemo' + k, kind: 'live', id: 'l' + k, name: c[0], poster: artLogo(c[0]), num: 101 + k, cat: 'dl' + c[1], epgId: 'demo' + k, url: 'demo://live/' + k, archive: k < 8 ? 1 : 0, archiveDays: 2 }); });
  return D;
}
function demoEpg(it) {
  var R = rng(parseInt(hash(it.key), 36)), pick = function (a) { return a[Math.floor(R() * a.length)]; };
  var T = { dl0: ['Buongiorno Levante', 'Il grande quiz', 'Cucina di casa', 'Telegiornale', 'Film della sera: Il faro di Ostuni', 'Talk del venerdì'], dl1: ['Edizione delle 16', 'Approfondimento', 'Rassegna stampa', 'Meteo e mari', 'Economia in breve'], dl2: ['Diretta campionato', 'Studio Sport', 'Highlights', 'Volley: semifinale', 'Paddock'], dl3: ['Le avventure di Pino', 'Laboratorio creativo', 'Il mondo di Lulù', 'Cartoni a merenda'], dl4: ['Classifica settimanale', 'Live in studio', 'Unplugged', 'Notte elettronica'], dl5: ['Viaggio nel Mediterraneo', 'Gli abissi del Gargano', 'Imperi perduti', 'La vita dei fari'] };
  var list = T[it.cat] || T.dl0, now = Date.now(), slot = 30 * 60000, t = Math.floor(now / slot) * slot - slot * Math.floor(R() * 2), out = [];
  for (var k = 0; k < 7; k++) { var len = slot * (1 + Math.floor(R() * 3)); out.push({ t: pick(list), d: 'Programma dimostrativo del canale ' + it.name + '. I titoli e gli orari sono inventati per mostrare la guida TV.', s: t, e: t + len }); t += len; }
  return out;
}
function demoArchive(it) {
  var R = rng(parseInt(hash(it.key + 'arc'), 36)), now = Date.now(), slot = 30 * 60000, t = Math.floor(now / slot) * slot, out = [];
  var T = ['Telegiornale', 'Il grande quiz', 'Documentario: il Gargano', 'Cucina di casa', 'Talk della sera', 'Film: Notte a Matera', 'Sport: sintesi', 'Rassegna stampa'];
  while (t > now - 36 * 3600e3) { var len = slot * (1 + Math.floor(R() * 3)), s0 = t - len; if (t <= now - 5 * 60000) out.push({ t: T[Math.floor(R() * T.length)], d: 'Programma dimostrativo già andato in onda su ' + it.name + '.', s: s0, e: t, start: '' }); t = s0; }
  return out;
}
function seedDemoUser() {
  if (Object.keys(S.user.plays).length || Object.keys(S.user.prog).length) return;
  var D = S.D, now = Date.now();
  [0, 5, 11].forEach(function (i, k) { var m = D.movie[i]; var sn = snapOf(m); S.user.prog[m.key] = { pos: m.dur * 1000 * (0.25 + k * 0.2), dur: m.dur * 1000, ts: now - k * 3600e3, item: sn }; S.user.plays[m.key] = { count: 3 - k, last: now - k * 3600e3, item: sn }; });
  var se = D.series[2], ep = se.seasonList[0].eps[2], es = epSnap(se, se.seasonList[0], ep);
  S.user.prog[ep.key] = { pos: ep.dur * 1000 * 0.4, dur: ep.dur * 1000, ts: now - 1800e3, item: es };
  S.user.lastEp[se.key] = { key: ep.key, ts: now };
  S.user.plays[se.key] = { count: 5, last: now, item: snapOf(se) };
  [D.movie[3], D.series[0], D.movie[20]].forEach(function (x) { S.user.fav[x.key] = snapOf(x); });
  [D.live[0], D.live[8]].forEach(function (x, k) { S.user.fav[x.key] = snapOf(x); S.user.plays[x.key] = { count: 4 - k, last: now, item: snapOf(x) }; });
  saveUser();
}

/* ================= catalogue loading ================= */
var ADULT = /(^|[^a-z])(xxx|adult[io]?|adults|porn\w*|18\s*\+|per adulti|for adults)([^a-z]|$)/i;
function buildView() {
  var D = S.D, V = { movie: [], series: [], live: [], cats: {}, byCat: { movie: {}, series: {}, live: {} } };
  ['movie', 'series', 'live'].forEach(function (k) {
    var hidden = {}, known = {};
    var userHidden = (S.user && S.user.hidden && S.user.hidden[k]) || {};
    var cats = D.cats[k].filter(function (c) { var h = (S.settings.hideAdult && ADULT.test(c.name)) || userHidden[c.id]; if (h) hidden[c.id] = 1; return !h; });
    cats.forEach(function (c) { known[c.id] = 1; });
    D[k].forEach(function (it) {
      if (hidden[it.cat] || (S.settings.hideAdult && ADULT.test(it.name))) return;
      if (!known[it.cat]) { known[it.cat] = 1; cats.push({ id: it.cat, name: it.cat && it.cat !== 'undefined' && it.cat !== 'null' && isNaN(+it.cat) ? it.cat : 'Altro' }); }
      V[k].push(it);
      (V.byCat[k][it.cat] = V.byCat[k][it.cat] || []).push(it);
    });
    V.cats[k] = cats.filter(function (c) { return V.byCat[k][c.id]; });
  });
  S.V = V; S.idx = {};
  ['movie', 'series', 'live'].forEach(function (k) { V[k].forEach(function (it) { S.idx[it.key] = it; }); });
  S.grid.movie.cat = S.grid.series.cat = '__all';
  S.live.cat = '__all';
  S.epg = {}; xmltvP = null; S.hero = []; S.mindex = null;
}
function catKey(s) { return 'cat:' + s.id + ':' + hash((s.server || '') + '|' + (s.user || '') + '|' + (s.m3u || '')); }
function fetchCatalog(s, step) {
  if (s.type === 'demo') return Promise.resolve(demoCatalog());
  return s.type === 'xtream' ? loadXtream(s, step) : loadM3U(s, step);
}
function loadCatalog(s, force) {
  if (s.type === 'demo') return Promise.resolve(demoCatalog());
  var key = catKey(s);
  return (force ? Promise.resolve(null) : IDB.get(key)).then(function (c) {
    if (c && c.v === CAT_V && c.D) {
      if (Date.now() - c.ts > 12 * 3600e3) refreshInBackground(s);
      return c.D;
    }
    return fetchCatalog(s, setLoad).then(function (D) { D.ts = Date.now(); IDB.set(key, { v: CAT_V, ts: D.ts, D: D }); return D; });
  });
}
function refreshInBackground(s) {
  fetchCatalog(s, function () {}).then(function (D) {
    D.ts = Date.now(); IDB.set(catKey(s), { v: CAT_V, ts: D.ts, D: D });
    if (S.activeId !== s.id) return;
    S.D = D; buildView(); toast('Catalogo aggiornato.');
    if (!S.overlay && (S.view === 'home' || S.view === 'settings')) refresh();
  }).catch(function () {});
}
function setLoad(msg) { $('#loadmsg').textContent = msg; }
function showLoader(on, msg) { $('#loader').hidden = !on; if (msg) setLoad(msg); }

function start(force) {
  var s = src();
  if (!s) { $('#app').classList.add('norail'); showLoader(false); S.form = { type: 'xtream', err: '', first: true }; go('setup'); return; }
  loadUser();
  showLoader(true, s.type === 'demo' ? 'Preparo il catalogo dimostrativo…' : 'Carico il catalogo…');
  loadCatalog(s, force).then(function (D) {
    S.D = D; buildView();
    if (s.type === 'demo') seedDemoUser();
    $('#app').classList.remove('norail');
    showLoader(false);
    go('home');
    if (!S.booted) {
      S.booted = true;
      if (S.settings.startLast && S.user.lastCh && S.idx[S.user.lastCh]) setTimeout(function () { playChannel(S.user.lastCh); }, 400);
    }
    if (D.account && D.account.status && D.account.status !== 'Active') toast('Attenzione: il server indica che l’abbonamento è «' + D.account.status + '».');
  }).catch(function (err) {
    showLoader(false);
    $('#app').classList.toggle('norail', S.sources.length < 2 && !S.D);
    S.form = Object.assign(formFrom(s), { err: err.message, first: !S.D });
    go('setup');
  });
}

/* ================= TMDB & OMDb ================= */
var META = { mem: {}, pend: {} };
var TMDB_IMG = 'https://image.tmdb.org/t/p/';
function tmdbOn() { return !!(S.settings.tmdbKey || '').trim(); }
function fetchJson(url, headers) {
  return fetch(url, { headers: headers || {} }).then(function (r) {
    if (r.status === 401) { var e = new Error('unauthorized'); e.status = 401; throw e; }
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.json();
  }, function (err) {
    if (NATIVE && !headers) return http(url).then(function (r) { return r.json(); });
    throw err;
  });
}
function tmdbFetch(path, params) {
  var k = (S.settings.tmdbKey || '').trim(), bearer = k.length > 60, q = Object.assign({ language: 'it-IT' }, params || {});
  if (!bearer) q.api_key = k;
  var url = 'https://api.themoviedb.org/3' + path + '?' + Object.keys(q).map(function (x) { return x + '=' + encodeURIComponent(q[x]); }).join('&');
  return fetchJson(url, bearer ? { Authorization: 'Bearer ' + k, Accept: 'application/json' } : null).catch(function (e) {
    if (e.status === 401) throw new Error('La chiave TMDB non è valida. Controllala nelle Impostazioni.');
    throw new Error('TMDB non risponde (' + e.message + ').');
  });
}
function cleanForMatch(n) {
  n = String(n || '');
  n = n.replace(/^\s*[\[(|]?[A-Z]{2,4}[\])|]?\s*[-:|]\s+/, '');
  n = n.replace(/\[[^\]]*\]|\([^)]*\)/g, ' ');
  n = n.replace(/\b(4k|uhd|fhd|hd|sd|hevc|h\.?265|x265|multi|multisub|sub[\s-]?ita|ita|eng|dual|3d|1080p|720p|2160p|hdr)\b/ig, ' ');
  return n.replace(/[_.]+/g, ' ').replace(/\s+/g, ' ').trim();
}
function matchKey(n) { return norm(cleanForMatch(n)).replace(/&/g, ' e ').replace(/[^a-z0-9]+/g, ' ').trim(); }
function pickBest(res, it) {
  var want = matchKey(it.name), y = +it.year || 0, best = null, bs = -1;
  res.slice(0, 8).forEach(function (r) {
    var t = matchKey(r.title || r.name), o = matchKey(r.original_title || r.original_name), ry = +(r.release_date || r.first_air_date || '').slice(0, 4) || 0, sc = 0;
    if (t === want || o === want) sc += 3; else if (t.indexOf(want) === 0 || want.indexOf(t) === 0) sc += 1;
    if (y && ry) { if (ry === y) sc += 2; else if (Math.abs(ry - y) === 1) sc += 1; else sc -= 2; }
    if (sc > bs) { bs = sc; best = r; }
  });
  return best && bs >= 2 ? best.id : null;
}
function lookupMeta(it) {
  var tv = it.kind === 'series', kind = tv ? 'tv' : 'movie';
  var idP = it.tmdbId ? Promise.resolve(it.tmdbId) : tmdbFetch('/search/' + kind, Object.assign({ query: cleanForMatch(it.name), include_adult: 'false' }, it.year ? (tv ? { first_air_date_year: it.year } : { year: it.year }) : {}))
    .then(function (r) {
      var id = pickBest(r.results || [], it);
      if (id || !it.year) return id;
      return tmdbFetch('/search/' + kind, { query: cleanForMatch(it.name), include_adult: 'false' }).then(function (r2) { return pickBest(r2.results || [], it); });
    });
  return idP.then(function (id) {
    if (!id) return null;
    return tmdbFetch('/' + kind + '/' + id, { append_to_response: 'credits,external_ids' }).then(function (d) {
      var crew = (d.credits && d.credits.crew) || [];
      var m = {
        tmdbId: d.id, plot: d.overview || '', tagline: d.tagline || '',
        poster: d.poster_path ? TMDB_IMG + 'w342' + d.poster_path : '', backdrop: d.backdrop_path ? TMDB_IMG + 'w1280' + d.backdrop_path : '',
        vote: d.vote_count >= 5 ? Math.round(d.vote_average * 10) / 10 : 0, votes: d.vote_count || 0,
        genres: (d.genres || []).map(function (g) { return g.name; }).slice(0, 3).join(', '),
        year: (d.release_date || d.first_air_date || '').slice(0, 4), runtime: d.runtime || (d.episode_run_time && d.episode_run_time[0]) || 0,
        cast: ((d.credits && d.credits.cast) || []).slice(0, 6).map(function (c) { return c.name; }).join(', '),
        director: tv ? (d.created_by || []).map(function (c) { return c.name; }).join(', ') : crew.filter(function (c) { return c.job === 'Director'; }).map(function (c) { return c.name; }).join(', '),
        imdbId: (d.external_ids && d.external_ids.imdb_id) || d.imdb_id || ''
      };
      var plotP = m.plot ? Promise.resolve() : tmdbFetch('/' + kind + '/' + id, { language: 'en-US' }).then(function (e) { m.plot = e.overview || ''; m.plotLang = 'en'; }, function () {});
      return plotP.then(function () { return omdbFor(m); }).then(function (r) { m.ratings = r; return m; });
    });
  });
}
function omdbFor(m) {
  var k = (S.settings.omdbKey || '').trim();
  if (!k || !m.imdbId) return Promise.resolve(null);
  return fetchJson('https://www.omdbapi.com/?apikey=' + encodeURIComponent(k) + '&i=' + encodeURIComponent(m.imdbId)).then(function (d) {
    if (!d || d.Response === 'False') return null;
    var r = {};
    if (d.imdbRating && d.imdbRating !== 'N/A') r.imdb = d.imdbRating;
    if (d.imdbVotes && d.imdbVotes !== 'N/A') r.imdbVotes = d.imdbVotes;
    (d.Ratings || []).forEach(function (x) { if (/rotten/i.test(x.Source)) r.rt = x.Value; });
    if (d.Metascore && d.Metascore !== 'N/A') r.mc = d.Metascore;
    return r;
  }).catch(function () { return null; });
}
function getMeta(it) {
  if (!tmdbOn() || (it.kind !== 'movie' && it.kind !== 'series')) return Promise.resolve(null);
  var key = 'meta1:' + it.kind + ':' + matchKey(it.name) + '|' + (it.year || '') + '|' + (it.tmdbId || '');
  if (META.mem[key] !== undefined) return Promise.resolve(META.mem[key]);
  if (META.pend[key]) return META.pend[key];
  META.pend[key] = IDB.get(key).then(function (c) {
    if (c && Date.now() - c.ts < (c.m ? 30 : 7) * 864e5) return c.m;
    return lookupMeta(it).then(function (m) { IDB.set(key, { ts: Date.now(), m: m }); return m; });
  }).then(function (m) { META.mem[key] = m; delete META.pend[key]; return m; }, function (e) { delete META.pend[key]; throw e; });
  return META.pend[key];
}
function applyMeta(it, m) {
  if (!m) return;
  it.meta = m;
  if (m.plot && (!it.plot || (S.settings.preferTmdb && m.plotLang !== 'en'))) it.plot = m.plot;
  if (m.backdrop && !it.backdrop) it.backdrop = m.backdrop;
  if (m.poster && !it.poster) it.poster = m.poster;
  if (m.cast && !it.cast) it.cast = m.cast;
  if (m.director && !it.director) it.director = m.director;
  if (m.genres && !it.genre) it.genre = m.genres;
  if (m.year && !it.year) it.year = m.year;
  if (m.vote && !it.rating) it.rating = m.vote;
  if (m.runtime && !it.dur && it.kind === 'movie') it.dur = m.runtime * 60;
  if (m.tmdbId) it.tmdbId = m.tmdbId;
}
function scoresHtml(it) {
  var m = it.meta, out = [];
  if (!m) return '';
  var r = m.ratings || {};
  if (m.vote) out.push('<span class="score"><span>TMDB</span><b>' + fmtRating(m.vote) + '</b></span>');
  if (r.imdb) out.push('<span class="score imdb"><span>IMDb</span><b>' + fmtRating(num(r.imdb)) + '</b></span>');
  if (r.rt) out.push('<span class="score rt"><span>Rotten Tomatoes</span><b>' + esc(r.rt) + '</b></span>');
  if (r.mc) out.push('<span class="score"><span>Metacritic</span><b>' + esc(r.mc) + '</b></span>');
  return out.length ? '<div class="scores">' + out.join('') + '</div>' : '';
}
function tmdbList(path, pages, params) {
  var ps = [];
  for (var i = 1; i <= pages; i++) ps.push(tmdbFetch(path, Object.assign({ page: i }, params || {})).then(function (d) { return d.results || []; }, function () { return []; }));
  return Promise.all(ps).then(function (r) {
    return [].concat.apply([], r).map(function (x) { return { id: x.id, t: x.title || x.name || '', o: x.original_title || x.original_name || '', y: (x.release_date || x.first_air_date || '').slice(0, 4) }; });
  });
}
function loadCharts() {
  if (!tmdbOn()) return Promise.resolve(null);
  if (S.charts && Date.now() - S.charts.ts < 6 * 3600e3) return Promise.resolve(S.charts);
  var key = 'charts1:' + hash(S.settings.tmdbKey);
  return IDB.get(key).then(function (c) {
    if (c && Date.now() - c.ts < 6 * 3600e3) return c;
    return Promise.all([tmdbList('/movie/popular', 4, { region: 'IT' }), tmdbList('/tv/popular', 4), tmdbList('/trending/movie/week', 3), tmdbList('/trending/tv/week', 3)]).then(function (r) {
      var c2 = { ts: Date.now(), popM: r[0], popT: r[1], trendM: r[2], trendT: r[3] };
      if (r[0].length || r[1].length) IDB.set(key, c2);
      return c2;
    });
  }).then(function (c) { S.charts = c; return c; });
}
function catalogIndex(kind) {
  S.mindex = S.mindex || {};
  if (S.mindex[kind]) return S.mindex[kind];
  var m = {};
  S.V[kind].forEach(function (it) { var k = matchKey(it.name); if (k) (m[k] = m[k] || []).push(it); });
  return (S.mindex[kind] = m);
}
function chartRow(list, kind, max, used) {
  var idx = catalogIndex(kind), out = [];
  used = used || {};
  (list || []).some(function (e) {
    var c = (idx[matchKey(e.t)] || []).concat(e.o ? (idx[matchKey(e.o)] || []) : []), y = +e.y, hit = null;
    c.forEach(function (it) { if (!hit && !used[it.key] && (!it.year || !y || Math.abs(+it.year - y) <= 1)) hit = it; });
    if (hit) { used[hit.key] = 1; if (!hit.tmdbId) hit.tmdbId = e.id; out.push(hit); }
    return out.length >= max;
  });
  return out;
}
function rankCard(it, i) {
  return '<button class="f card rank" data-act="open" data-key="' + esc(it.key) + '"><span class="rk">' + (i + 1) + '</span><span class="pw"><span class="poster">' + img(it.poster, dispName(it.name)) + rateBadge(it) + '</span><span class="cname">' + esc(dispName(it.name)) + '</span></span></button>';
}

/* ================= selections ================= */
function byAdded(a, b) { return (b.added || 0) - (a.added || 0); }
function byRating(a, b) { return (b.rating || 0) - (a.rating || 0) || byAdded(a, b); }
function byName(a, b) { return a.name.localeCompare(b.name, 'it'); }
function sorted(list, sort) { return list.slice().sort(sort === 'rating' ? byRating : sort === 'az' ? byName : byAdded); }
function recentList() { var all = S.V.movie.concat(S.V.series); if (!all.some(function (x) { return x.added; })) return []; return all.sort(byAdded).slice(0, 30); }
function topRated() { return S.V.movie.concat(S.V.series).filter(function (x) { return x.rating > 0; }).sort(byRating).slice(0, 30); }
function continueList() { var p = S.user.prog; return Object.keys(p).map(function (k) { return p[k]; }).filter(function (x) { return x.item; }).sort(function (a, b) { return b.ts - a.ts; }).slice(0, 20); }
function mostWatched(kinds) { var p = S.user.plays; return Object.keys(p).map(function (k) { return p[k]; }).filter(function (x) { return x.item && kinds.indexOf(x.item.kind) >= 0; }).sort(function (a, b) { return b.count - a.count || b.last - a.last; }).map(function (x) { return S.idx[x.item.key] || x.item; }); }
function favs(kinds) { var f = S.user.fav; return Object.keys(f).map(function (k) { return f[k]; }).filter(function (x) { return kinds.indexOf(x.kind) >= 0; }).sort(function (a, b) { return (b.ts || 0) - (a.ts || 0); }).map(function (x) { return S.idx[x.key] || x; }); }
function catName(kind, id) { var c = S.V.cats[kind]; for (var i = 0; i < c.length; i++) if (c[i].id === id) return c[i].name; return ''; }

/* ================= snapshots & playback ================= */
function snapOf(it) { return { key: it.key, kind: it.kind, id: it.id, name: it.name, poster: it.poster || '', backdrop: it.backdrop || '', rating: it.rating || 0, year: it.year || '', ext: it.ext || '', url: it.url || '', dur: it.dur || 0, ts: Date.now() }; }
function epSnap(se, season, ep) { return { key: ep.key, kind: 'episode', id: ep.id, ext: ep.ext || 'mp4', url: ep.url || '', seriesKey: se.key, name: se.name, sub: 'S' + season.n + ' · E' + ep.num + (ep.title ? ' · ' + ep.title : ''), poster: se.poster || '', backdrop: ep.thumb || se.backdrop || '', dur: ep.dur || 0 }; }
function pathSafe(v) { return String(v).replace(/[\/?#% ]/g, function (c) { return encodeURIComponent(c); }); }
function streamFor(it) {
  var s = src();
  if (it.url) return { url: it.url, mime: /\.m3u8(\?|$)/i.test(it.url) ? 'application/x-mpegURL' : '' };
  if (s && s.type === 'xtream') {
    var b = s.server, u = pathSafe(s.user), p = pathSafe(s.pass);
    if (it.kind === 'live') { var hls = S.settings.liveFormat === 'hls'; return { url: b + '/live/' + u + '/' + p + '/' + it.id + (hls ? '.m3u8' : '.ts'), mime: hls ? 'application/x-mpegURL' : '' }; }
    if (it.kind === 'movie') return { url: b + '/movie/' + u + '/' + p + '/' + it.id + '.' + (it.ext || 'mp4'), mime: '' };
    if (it.kind === 'episode') return { url: b + '/series/' + u + '/' + p + '/' + it.id + '.' + (it.ext || 'mp4'), mime: '' };
  }
  return { url: '', mime: '' };
}
function bumpPlays(sn) {
  var item = sn.kind === 'episode' ? (S.idx[sn.seriesKey] ? snapOf(S.idx[sn.seriesKey]) : { key: sn.seriesKey, kind: 'series', name: sn.name, poster: sn.poster }) : snapOf(sn);
  var p = S.user.plays[item.key] || { count: 0 };
  p.count++; p.last = Date.now(); p.item = item;
  S.user.plays[item.key] = p;
}
function startPlayback(snaps, index, live, startMs) {
  var list = snaps.map(function (sn) { var st = streamFor(sn); S.pending[sn.key] = sn; return { url: st.url, mime: st.mime, title: sn.name, subtitle: sn.sub || '', key: sn.key }; });
  var cur = snaps[index];
  if (cur.kind !== 'catchup') bumpPlays(cur);
  if (cur.kind === 'episode') S.user.lastEp[cur.seriesKey] = { key: cur.key, ts: Date.now() };
  if (live) S.user.lastCh = cur.key;
  saveUser();
  var s = src();
  if (!NATIVE || s.type === 'demo') { simulatePlayback(cur, live); return; }
  var st = S.settings;
  try {
    if (st.player === 'external' && window.OrbitaNative.openExternal) { window.OrbitaNative.openExternal(JSON.stringify(list[index])); return; }
    window.OrbitaNative.play(JSON.stringify({ playlist: list, index: index, live: !!live, startMs: startMs || 0, ua: st.ua, prefs: { buffer: st.buffer, audioLang: st.audioLang, subLang: st.subLang, subSize: st.subSize, subBg: !!st.subBg } }));
  }
  catch (e) { toast('Non riesco ad aprire il lettore: ' + e.message); }
}
function simulatePlayback(sn, live) {
  toast((live ? 'Anteprima: qui si aprirebbe il canale «' : 'Anteprima: qui partirebbe «') + sn.name + (sn.sub ? ' – ' + sn.sub : '') + '» nel lettore a schermo intero.');
  if (live || sn.kind === 'catchup') { if (S.view === 'home') refresh(); return; }
  var dur = (sn.dur || 5400) * 1000, prev = S.user.prog[sn.key];
  var pos = Math.min(dur * 0.9, (prev ? prev.pos : 0) + dur * 0.22);
  setTimeout(function () { window.onNativePlaybackEnded(JSON.stringify({ updates: [{ key: sn.key, posMs: pos, durMs: dur, ended: false, live: false }] })); }, 400);
}
window.onNativePlaybackEnded = function (res) {
  var d; try { d = typeof res === 'string' ? JSON.parse(res) : res; } catch (e) { return; }
  (d.updates || []).forEach(function (u) {
    var sn = S.pending[u.key];
    if (!sn || u.live || (sn.kind !== 'movie' && sn.kind !== 'episode')) return;
    var pos = num(u.posMs), dur = num(u.durMs);
    if (sn.kind === 'episode') {
      Object.keys(S.user.prog).forEach(function (k) { var p = S.user.prog[k]; if (p.item && p.item.seriesKey === sn.seriesKey) delete S.user.prog[k]; });
      S.user.lastEp[sn.seriesKey] = { key: sn.key, ts: Date.now() };
    }
    if (u.ended || (dur > 0 && pos / dur > 0.94)) { delete S.user.prog[u.key]; S.user.watched[u.key] = Date.now(); }
    else if (pos > 20000) { if (!sn.dur && dur) sn.dur = dur / 1000; S.user.prog[u.key] = { pos: pos, dur: dur, ts: Date.now(), item: sn }; }
  });
  saveUser();
  refresh();
};

/* ================= focus & remote navigation ================= */
function scopeEl() { return S.modal ? $('#modal') : S.overlay ? $('#ov') : $('#app'); }
function candidates() {
  return Array.prototype.filter.call(scopeEl().querySelectorAll('.f'), function (el) { return !el.disabled && el.getClientRects().length > 0; });
}
function focusEl(el) {
  if (!el) return;
  try { el.focus({ preventScroll: true }); } catch (e) { el.focus(); }
  ensureVisible(el);
}
function ensureVisible(el) {
  var tr = el.closest('.track');
  if (tr) {
    var a = tr.getBoundingClientRect(), b = el.getBoundingClientRect(), pad = Math.min(56, a.width * 0.08);
    if (b.left < a.left + pad) tr.scrollLeft -= (a.left + pad - b.left);
    else if (b.right > a.right - pad) tr.scrollLeft += (b.right - (a.right - pad));
  }
  var sc = el.parentElement && el.parentElement.closest('.scroller, .lcol, .ov-body, .g-rows');
  if (!sc) return;
  if (el.closest('.hero')) { sc.scrollTop = 0; return; }
  var tgt = el.closest('.shelf') || el, A = sc.getBoundingClientRect(), B = tgt.getBoundingClientRect(), m = Math.min(60, A.height * 0.08);
  if (B.top < A.top + m || B.bottom > A.bottom - m) {
    if (tgt.classList.contains('shelf') && B.height < A.height * 0.8) sc.scrollTop += B.top - A.top - A.height * 0.16;
    else if (B.top < A.top + m) sc.scrollTop += B.top - A.top - m;
    else sc.scrollTop += B.bottom - A.bottom + m;
  }
}
function move(dir) {
  var cur = document.activeElement, list = candidates();
  if (!cur || list.indexOf(cur) < 0) { focusEl(list.filter(function (e) { return !e.closest('#rail'); })[0] || list[0]); return; }
  if (S.view === 'live' && !S.overlay) {
    var jump = null;
    if (dir === 'left' && cur.closest('#pane')) jump = stage.querySelector('.ch.on') || stage.querySelector('.ch');
    else if (dir === 'left' && cur.classList.contains('ch')) jump = stage.querySelector('.lc.on');
    else if (dir === 'right' && cur.classList.contains('lc')) jump = stage.querySelector('.ch.on') || stage.querySelector('.ch');
    else if (dir === 'right' && cur.classList.contains('ch')) jump = $('#pane .btn.pri');
    else if (dir === 'left' && cur.classList.contains('g-cell') && !(cur.previousElementSibling && cur.previousElementSibling.classList.contains('g-cell'))) jump = stage.querySelector('.lc.on');
    else if (dir === 'right' && cur.classList.contains('lc') && S.live.mode === 'grid') jump = stage.querySelector('.g-cell.now') || stage.querySelector('.g-cell');
    if (jump) { focusEl(jump); return; }
  }
  if (dir === 'right' && cur.closest('#rail') && S.lastContent && document.contains(S.lastContent) && S.lastContent.getClientRects().length) { focusEl(S.lastContent); return; }
  var r = cur.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2, W = window.innerWidth, best = null, bs = Infinity;
  for (var i = 0; i < list.length; i++) {
    var el = list[i]; if (el === cur) continue;
    var b = el.getBoundingClientRect(), bx = b.left + b.width / 2, by = b.top + b.height / 2, p, s, ov;
    if (dir === 'right' || dir === 'left') {
      if (dir === 'right' ? (b.left < r.right - r.width * 0.2 || bx <= cx) : (b.right > r.left + r.width * 0.2 || bx >= cx)) continue;
      p = dir === 'right' ? Math.max(0, b.left - r.right) : Math.max(0, r.left - b.right);
      ov = b.top < r.bottom && b.bottom > r.top;
      s = ov ? Math.abs(by - cy) * 0.1 : Math.abs(by - cy) * 3 + 400;
    } else {
      if (dir === 'down' ? (b.top < r.bottom - r.height * 0.2 || by <= cy) : (b.bottom > r.top + r.height * 0.2 || by >= cy)) continue;
      if (b.right < 0 || b.left > W) continue;
      p = dir === 'down' ? Math.max(0, b.top - r.bottom) : Math.max(0, r.top - b.bottom);
      ov = b.left < r.right && b.right > r.left;
      s = ov ? Math.abs(bx - cx) * 0.3 : Math.abs(bx - cx) * 1.5;
    }
    var sc = p + s;
    if (sc < bs) { bs = sc; best = el; }
  }
  if (!best) return;
  if (dir === 'up' || dir === 'down') {
    var tr = best.closest('.track');
    if (tr && tr.__last && tr.__last !== best && document.contains(tr.__last) && cur.closest('.track') !== tr) {
      var lb = tr.__last.getBoundingClientRect();
      if (lb.right > 0 && lb.left < W && lb.width) best = tr.__last;
    }
  }
  focusEl(best);
}
document.addEventListener('focusin', function (e) {
  var t = e.target;
  if (!t.classList || !t.classList.contains('f')) return;
  var tr = t.closest('.track'); if (tr) tr.__last = t;
  if (!t.closest('#rail') && !t.closest('#ov') && !t.closest('#modal')) S.lastContent = t;
  var ri = t.closest('.g-row'); if (ri && +ri.getAttribute('data-ri') >= S.guideShown - 8) appendGuide();
  var gi = t.getAttribute('data-gi'); if (gi != null && +gi >= S.gridShown - 14) appendGrid();
  var li = t.getAttribute('data-li'); if (li != null && +li >= S.live.shown - 20) appendChannels();
  if (t.getAttribute('data-act') === 'live-ch') selectChannel(t.getAttribute('data-key'));
});
function focusFirst(root) {
  var el = Array.prototype.filter.call((root || stage).querySelectorAll('.f'), function (e) { return e.getClientRects().length; })[0];
  focusEl(el);
}

window.orbitaBack = function () {
  var a = document.activeElement;
  if (S.modal) { closeModal(); return true; }
  if (S.overlay) { closeOverlay(); return true; }
  if ((S.view === 'setup' && src() && S.D) || S.view === 'cats') { go('settings'); return true; }
  if (S.view !== 'home' && S.view !== 'setup') { go('home', { focusRail: true }); return true; }
  if (a && !a.closest('#rail') && S.view === 'home') { focusEl($('#rail [data-v="home"]')); return true; }
  if (!S.exitArmed) { S.exitArmed = true; toast('Premi di nuovo Indietro per uscire.'); setTimeout(function () { S.exitArmed = false; }, 2500); return true; }
  return false;
};
window.addEventListener('keydown', function (e) {
  var k = e.key, c = e.keyCode, a = document.activeElement;
  var dir = (k === 'ArrowUp' || c === 38) ? 'up' : (k === 'ArrowDown' || c === 40) ? 'down' : (k === 'ArrowLeft' || c === 37) ? 'left' : (k === 'ArrowRight' || c === 39) ? 'right' : null;
  var inInput = a && a.tagName === 'INPUT';
  if (dir) {
    if (inInput && (dir === 'left' || dir === 'right')) {
      var v = a.value || '', pos = a.selectionStart;
      if ((dir === 'left' && pos > 0) || (dir === 'right' && pos < v.length)) return;
    }
    e.preventDefault(); move(dir); return;
  }
  if (S.modal && /^[0-9]$/.test(k)) { e.preventDefault(); pinKey(k); return; }
  if (k === 'Enter' || c === 13) {
    if (inInput) { if (a.id === 'q') { e.preventDefault(); move('down'); } return; }
    if (a && a.classList && a.classList.contains('f')) { e.preventDefault(); a.click(); }
    return;
  }
  if (!NATIVE && (k === 'Escape' || (k === 'Backspace' && !inInput))) {
    e.preventDefault();
    window.orbitaBack();
  }
});

/* ================= rendering helpers ================= */
function rateBadge(it) { return it.rating ? '<span class="rate">★ ' + fmtRating(it.rating) + '</span>' : ''; }
function progOf(key) { var p = S.user.prog[key]; return p && p.dur ? Math.max(2, Math.min(100, Math.round(p.pos / p.dur * 100))) : 0; }
function posterCard(it, i) {
  var pr = progOf(it.key);
  return '<button class="f card" data-act="open" data-key="' + esc(it.key) + '"' + (i != null ? ' data-gi="' + i + '"' : '') + '><span class="poster">' + img(it.poster, dispName(it.name)) + rateBadge(it) +
    (S.user.fav[it.key] ? '<span class="tick" aria-label="Nella tua lista">' + IC.check + '</span>' : '') +
    (pr ? '<span class="bar"><i style="width:' + pr + '%"></i></span>' : '') + '</span><span class="cname">' + esc(dispName(it.name)) + '</span></button>';
}
function continueCard(p) {
  var it = p.item, pr = progOf(it.key), left = p.dur ? Math.max(1, Math.round((p.dur - p.pos) / 60000)) : 0;
  return '<button class="f card wide" data-act="resume" data-key="' + esc(it.key) + '"><span class="poster">' + img(it.backdrop || it.poster, it.name, it.backdrop ? 'wide' : 'poster') +
    '<span class="ov"><b>' + esc(dispName(it.name)) + '</b><span>' + esc(it.sub ? it.sub : '') + (it.sub && left ? ' · ' : '') + (left ? 'Restano ' + left + ' min' : '') + '</span></span>' +
    '<span class="bar"><i style="width:' + pr + '%"></i></span></span></button>';
}
function chanCard(it) {
  return '<button class="f card chan" data-act="open" data-key="' + esc(it.key) + '"><span class="poster">' + img(it.poster, it.name, 'logo') + '</span><span class="cname">' + (it.num ? it.num + ' · ' : '') + esc(it.name) + '</span></button>';
}
function moreCard(kind, cat, sort) {
  return '<button class="f card more" data-act="see-all" data-kind="' + kind + '" data-cat="' + esc(cat) + '" data-sort="' + sort + '"><span class="poster"><span>' + IC.arrow + 'Vedi tutti</span></span><span class="cname">&nbsp;</span></button>';
}
function metaLine(it) {
  var p = [];
  if (it.year) p.push(esc(it.year));
  if (it.rating) p.push('<span class="star">★ ' + fmtRating(it.rating) + '</span>');
  if (it.dur) p.push(fmtDur(it.dur));
  if (it.kind === 'series' && it.seasonList) p.push(it.seasonList.length + (it.seasonList.length === 1 ? ' stagione' : ' stagioni'));
  if (it.genre) p.push(esc(String(it.genre).split(/[,/]/).slice(0, 2).join(' · ')));
  return '<p class="meta">' + p.map(function (x) { return '<span>' + x + '</span>'; }).join('') + '</p>';
}

/* ================= views ================= */
var VIEWS = {};
function go(view, opts) {
  opts = opts || {};
  S.view = view; stopHero();
  if (S.io) { S.io.disconnect(); S.io = null; }
  stage.className = 'scroller' + (view === 'live' ? ' fixed' : '');
  stage.scrollTop = 0;
  stage.innerHTML = VIEWS[view]();
  gq.length = 0;
  var railV = view === 'cats' || view === 'setup' ? 'settings' : view;
  Array.prototype.forEach.call(document.querySelectorAll('#rail .rb'), function (b) { b.classList.toggle('on', b.getAttribute('data-v') === railV); });
  var handled = AFTER[view] ? AFTER[view](opts) : false;
  if (opts.focusRail) focusEl($('#rail [data-v="' + view + '"]') || $('#rail .rb'));
  else if (!opts.noFocus && !opts.focusSel && handled !== true) focusFirst();
  if (opts.focusSel) focusEl(stage.querySelector(opts.focusSel) || stage.querySelector('.f'));
}
var AFTER = {};
function refresh(from) {
  if (S.overlay) { renderOverlay(); return; }
  var a = from || document.activeElement, sel = null, keep = stage.scrollTop, shelf = a && a.closest && a.closest('.shelf');
  var shelfIdx = shelf ? +shelf.getAttribute('data-shelf') : -1;
  if (a && a.getAttribute && a.getAttribute('data-act') && stage.contains(a)) {
    sel = '[data-act="' + a.getAttribute('data-act') + '"]' + (a.getAttribute('data-key') ? '[data-key="' + a.getAttribute('data-key') + '"]' : '') + (a.getAttribute('data-v') ? '[data-v="' + a.getAttribute('data-v') + '"]' : '');
  }
  var railFocus = a && a.closest && a.closest('#rail');
  go(S.view, { noFocus: true });
  stage.scrollTop = keep;
  if (shelfIdx >= 0 && S.view === 'home') fillShelf(shelfIdx);
  if (railFocus) a.focus();
  else if (sel && stage.querySelector(sel)) focusEl(stage.querySelector(sel));
  else focusFirst();
}

/* ---- home ---- */
VIEWS.home = function () {
  var V = S.V, sh = [];
  var cont = continueList(); if (cont.length) sh.push({ title: 'Continua a guardare', type: 'cont', items: cont });
  if (S.charts) {
    var cm = chartRow(S.charts.popM, 'movie', 10), ct = chartRow(S.charts.popT, 'series', 10);
    if (cm.length >= 3) sh.push({ title: 'Top 10 film in Italia', type: 'rank', items: cm });
    if (ct.length >= 3) sh.push({ title: 'Top 10 serie TV', type: 'rank', items: ct });
  }
  var rec = recentList(); if (rec.length) sh.push({ title: 'Aggiunti di recente', items: rec });
  if (S.charts) {
    var tm = chartRow(S.charts.trendM, 'movie', 12), tt = chartRow(S.charts.trendT, 'series', 12), tr = [];
    for (var q = 0; q < 12; q++) { if (tm[q]) tr.push(tm[q]); if (tt[q]) tr.push(tt[q]); }
    if (tr.length >= 3) sh.push({ title: 'Di tendenza questa settimana', items: tr.slice(0, 20) });
  }
  var top = topRated(); if (top.length) sh.push({ title: 'I più votati', items: top });
  var mw = mostWatched(['movie', 'series']); if (mw.length) sh.push({ title: 'I più visti da te', items: mw.slice(0, 20) });
  var fl = favs(['movie', 'series']); if (fl.length) sh.push({ title: 'La mia lista', items: fl });
  var ch = favs(['live']); mostWatched(['live']).forEach(function (c) { if (!ch.some(function (x) { return x.key === c.key; })) ch.push(c); });
  if (ch.length) sh.push({ title: 'I tuoi canali', type: 'chan', items: ch.slice(0, 20) });
  var mc = V.cats.movie.filter(function (c) { return V.byCat.movie[c.id].length >= 3; }), scs = V.cats.series.filter(function (c) { return V.byCat.series[c.id].length >= 3; });
  for (var i = 0; i < 12 && (mc[i] || scs[i]); i++) {
    if (mc[i]) sh.push({ title: mc[i].name, kind: 'movie', cat: mc[i].id, items: V.byCat.movie[mc[i].id] });
    if (scs[i]) sh.push({ title: scs[i].name + ' · Serie', kind: 'series', cat: scs[i].id, items: V.byCat.series[scs[i].id] });
  }
  S.shelves = sh;
  if (!S.hero.length || S.heroSrc !== S.activeId) { S.hero = pickHero(); S.heroSrc = S.activeId; }
  var html = S.hero.length ? '<section class="hero" id="hero"></section>' : '<div class="vhead"><h1>Home</h1></div>';
  if (!V.movie.length && !V.series.length && !V.live.length) html += '<div class="empty"><h2>Il catalogo è vuoto</h2><p>La playlist è stata caricata ma non contiene contenuti. Controlla il link nelle Impostazioni o aggiorna il catalogo.</p></div>';
  html += '<div class="shelves">' + sh.map(function (s, k) {
    var count = s.kind ? '<small>' + s.items.length + ' titoli</small>' : '';
    return '<section class="shelf" data-shelf="' + k + '"><h2>' + esc(s.title) + count + '</h2><div class="track" data-fill="' + k + '"></div></section>';
  }).join('') + '</div>';
  return html;
};
function fillShelf(k) {
  var s = S.shelves[k], el = stage.querySelector('[data-fill="' + k + '"]');
  if (!s || !el || el.__filled) return;
  el.__filled = true;
  if (s.type === 'rank') { el.innerHTML = s.items.map(rankCard).join(''); return; }
  var items = s.type === 'cont' || s.type === 'chan' ? s.items : (s.kind ? sorted(s.items, 'recent').slice(0, 24) : s.items.slice(0, 30));
  el.innerHTML = items.map(function (it) { return s.type === 'cont' ? continueCard(it) : s.type === 'chan' ? chanCard(it) : posterCard(it); }).join('') + (s.kind && s.items.length > 24 ? moreCard(s.kind, s.cat, 'recent') : '');
}
AFTER.home = function () {
  renderHero();
  for (var k = 0; k < Math.min(4, S.shelves.length); k++) fillShelf(k);
  if ('IntersectionObserver' in window) {
    S.io = new IntersectionObserver(function (ents) { ents.forEach(function (e) { if (e.isIntersecting) fillShelf(+e.target.getAttribute('data-shelf')); }); }, { root: stage, rootMargin: '0px 0px 700px 0px' });
    Array.prototype.forEach.call(stage.querySelectorAll('.shelf'), function (el) { S.io.observe(el); });
  } else for (var j = 0; j < S.shelves.length; j++) fillShelf(j);
  startHero();
  if (tmdbOn() && !S.charts && !S.chartsBusy) {
    S.chartsBusy = true;
    loadCharts().then(function () { S.chartsBusy = false; if (S.view === 'home' && !S.overlay && !S.modal) refresh(); }, function () { S.chartsBusy = false; });
  }
};
function pickHero() {
  var pool = S.V.movie.concat(S.V.series).filter(function (x) { return x.poster; });
  if (!pool.length) return [];
  pool = pool.sort(byAdded).slice(0, 80);
  var good = pool.filter(function (x) { return x.rating >= 6.5; });
  if (good.length >= 5) pool = good;
  var out = [], used = {};
  while (out.length < Math.min(5, pool.length)) { var x = pool[Math.floor(Math.random() * pool.length)]; if (!used[x.key]) { used[x.key] = 1; out.push(x); } }
  S.heroIdx = 0;
  return out;
}
function renderHero(keepFocus) {
  var el = $('#hero'); if (!el || !S.hero.length) return;
  var it = S.hero[S.heroIdx], bd = it.backdrop, kindLbl = it.kind === 'series' ? 'Serie TV' : 'Film';
  var cat = catName(it.kind, it.cat), inList = !!S.user.fav[it.key];
  var a = document.activeElement, focusAct = keepFocus && a && el.contains(a) ? a.getAttribute('data-act') : null;
  el.innerHTML = '<div class="hero-bg' + (bd ? '' : ' soft') + '" style="background-image:url(&quot;' + esc(bd || it.poster) + '&quot;)"></div><div class="hero-shade"></div>' +
    '<div class="hero-in"><div class="hero-txt"><p class="eyebrow">In evidenza · ' + kindLbl + (cat ? ' · ' + esc(cat) : '') + '</p><h1>' + esc(dispName(it.name)) + '</h1>' + metaLine(it) +
    (it.plot ? '<p class="plot">' + esc(it.plot) + '</p>' : '<p class="plot" id="heroplot"></p>') +
    '<div class="actions"><button class="f btn pri" data-act="hero-play" data-key="' + esc(it.key) + '">' + IC.play + (it.kind === 'series' ? 'Guarda' : (S.user.prog[it.key] ? 'Riprendi' : 'Guarda')) + '</button>' +
    '<button class="f btn" data-act="open" data-key="' + esc(it.key) + '">' + IC.info + 'Dettagli</button>' +
    '<button class="f btn" data-act="fav" data-key="' + esc(it.key) + '">' + (inList ? IC.check + 'Nella lista' : IC.plus + 'La mia lista') + '</button></div></div>' +
    (bd ? '' : '<div class="hero-poster">' + img(it.poster, it.name) + '</div>') + '</div>' +
    '<div class="dots">' + S.hero.map(function (h, k) { return '<i class="' + (k === S.heroIdx ? 'on' : '') + '"></i>'; }).join('') + '</div>';
  if (focusAct) focusEl(el.querySelector('[data-act="' + focusAct + '"]'));
  if (!it.plot && it.kind === 'movie') loadDetails(it).then(function () { var p = $('#heroplot'); if (p && S.hero[S.heroIdx] === it) p.textContent = it.plot || ''; });
  if (tmdbOn() && !it._metaTried) {
    it._metaTried = true;
    getMeta(it).then(function (m) { if (!m) return; applyMeta(it, m); if (S.view === 'home' && S.hero[S.heroIdx] === it && !S.overlay) renderHero(true); }, function () {});
  }
}
function startHero() {
  stopHero();
  if (S.hero.length < 2) return;
  S.heroTimer = setInterval(function () {
    if (S.view !== 'home' || S.overlay || document.hidden) return;
    var a = document.activeElement, h = $('#hero');
    if (h && a && h.contains(a)) return;
    S.heroIdx = (S.heroIdx + 1) % S.hero.length; renderHero();
  }, 10000);
}
function stopHero() { if (S.heroTimer) clearInterval(S.heroTimer); S.heroTimer = null; }

/* ---- film / serie grid ---- */
S.gridShown = 0;
function gridView(kind) {
  var g = S.grid[kind], cats = S.V.cats[kind], total = S.V[kind].length;
  var list = g.cat === '__all' ? S.V[kind] : (S.V.byCat[kind][g.cat] || []);
  g.list = sorted(list, g.sort);
  var sorts = [['recent', 'Recenti'], ['rating', 'Più votati'], ['az', 'A–Z']].map(function (o) { return '<button class="f chip' + (g.sort === o[0] ? ' on' : '') + '" data-act="sort" data-kind="' + kind + '" data-v="' + o[0] + '">' + o[1] + '</button>'; }).join('');
  var chips = '<button class="f chip' + (g.cat === '__all' ? ' on' : '') + '" data-act="cat" data-kind="' + kind + '" data-key="__all">Tutti <small>' + total + '</small></button>' +
    cats.map(function (c) { return '<button class="f chip' + (g.cat === c.id ? ' on' : '') + '" data-act="cat" data-kind="' + kind + '" data-key="' + esc(c.id) + '">' + esc(c.name) + '</button>'; }).join('');
  if (!total) return '<div class="vhead"><h1>' + (kind === 'movie' ? 'Film' : 'Serie TV') + '</h1></div><div class="empty"><h2>Nessun titolo</h2><p>Questa playlist non contiene ' + (kind === 'movie' ? 'film' : 'serie TV') + '. Le playlist M3U con soli canali in diretta mostrano i contenuti nella sezione In diretta.</p></div>';
  return '<div class="vhead"><h1>' + (kind === 'movie' ? 'Film' : 'Serie TV') + '</h1><span class="count">' + g.list.length + ' titoli</span><div class="sorts">' + sorts + '</div></div>' +
    '<div class="track chips">' + chips + '</div><div class="grid" id="grid"></div>';
}
function appendGrid() {
  var grid = $('#grid'); if (!grid || (S.view !== 'movie' && S.view !== 'series')) return;
  var g = S.grid[S.view], from = S.gridShown, to = Math.min(g.list.length, from + 60);
  if (from >= to) return;
  grid.insertAdjacentHTML('beforeend', g.list.slice(from, to).map(function (it, i) { return posterCard(it, from + i); }).join(''));
  S.gridShown = to;
}
VIEWS.movie = function () { return gridView('movie'); };
VIEWS.series = function () { return gridView('series'); };
AFTER.movie = AFTER.series = function () { S.gridShown = 0; appendGrid(); appendGrid(); };

/* ---- live ---- */
function liveList(cat) {
  if (cat === '__fav') return favs(['live']).filter(function (x) { return S.idx[x.key]; });
  if (cat === '__top') return mostWatched(['live']).filter(function (x) { return S.idx[x.key]; });
  var l = cat === '__all' ? S.V.live : (S.V.byCat.live[cat] || []);
  return l.slice().sort(function (a, b) { return (a.num || 0) - (b.num || 0); });
}
VIEWS.live = function () {
  if (!S.V.live.length) return '<div class="vhead"><h1>In diretta</h1></div><div class="empty"><h2>Nessun canale</h2><p>Questa playlist non contiene canali in diretta.</p></div>';
  var L = S.live, nf = favs(['live']).length, nt = mostWatched(['live']).length;
  var cats = [['__fav', 'Preferiti', nf], ['__top', 'Più visti', nt], ['__all', 'Tutti i canali', S.V.live.length]].concat(S.V.cats.live.map(function (c) { return [c.id, c.name, S.V.byCat.live[c.id].length]; }));
  L.list = liveList(L.cat);
  var modes = '<div class="lmode"><button class="f chip' + (L.mode === 'list' ? ' on' : '') + '" data-act="live-mode" data-v="list">Elenco</button><button class="f chip' + (L.mode === 'grid' ? ' on' : '') + '" data-act="live-mode" data-v="grid">Guida TV</button></div>';
  var right = L.mode === 'grid' ? '<div class="guide"><div class="g-head"><div class="g-sp"></div><div class="g-ruler" id="ruler"></div></div><div class="g-rows" id="grows"></div></div>' : '<div class="lcol lchans" id="chans"></div><aside class="pane" id="pane"></aside>';
  return '<div class="live"><div class="lcol lcats"><h1 class="lhead">In diretta</h1>' + modes + cats.map(function (c) {
    return '<button class="f lc' + (L.cat === c[0] ? ' on' : '') + '" data-act="live-cat" data-key="' + esc(c[0]) + '"><span>' + esc(c[1]) + '</span><small>' + c[2] + '</small></button>';
  }).join('') + '</div>' + right + '</div>';
};
function chRow(it, i) {
  var ep = S.epg[it.key], now = ep && ep.list[0] && ep.list[0].s <= Date.now() ? ep.list[0].t : '';
  return '<button class="f ch' + (S.live.sel === it.key ? ' on' : '') + '" data-act="live-ch" data-key="' + esc(it.key) + '" data-li="' + i + '"><span class="num">' + (it.num || '') + '</span>' + img(it.poster, it.name, 'logo') +
    '<span class="nm">' + esc(it.name) + (now ? '<span class="nowt">' + esc(now) + '</span>' : '') + '</span>' + (S.user.fav[it.key] ? '<span class="fav">★</span>' : '') + '</button>';
}
function appendChannels() {
  var box = $('#chans'); if (!box) return;
  var L = S.live, from = L.shown, to = Math.min(L.list.length, from + 120);
  if (!L.list.length && !from) { box.innerHTML = '<p class="noepg" style="padding:.8rem">' + (L.cat === '__fav' ? 'Nessun canale preferito. Apri un canale e scegli «Aggiungi ai preferiti».' : 'Ancora nessun canale visto.') + '</p>'; return; }
  if (from >= to) return;
  box.insertAdjacentHTML('beforeend', L.list.slice(from, to).map(function (it, i) { return chRow(it, from + i); }).join(''));
  L.shown = to;
}
AFTER.live = function (opts) {
  if (S.live.mode === 'grid') return afterGuide(opts);
  S.live.shown = 0; appendChannels();
  var first = S.live.list[0];
  if (first && !S.live.sel) S.live.sel = first.key;
  renderPane(S.live.sel && S.idx[S.live.sel] ? S.idx[S.live.sel] : first);
  if (!opts.noFocus && !opts.focusRail) {
    var c = stage.querySelector('.ch.on') || stage.querySelector('.ch') || stage.querySelector('.lc.on');
    if (c) { focusEl(c); return true; }
  }
};
var selectChannel = debounce(function (key) {
  var it = S.idx[key]; if (!it) return;
  S.live.sel = key;
  Array.prototype.forEach.call(document.querySelectorAll('.ch.on'), function (e) { e.classList.remove('on'); });
  var row = stage.querySelector('.ch[data-key="' + key + '"]'); if (row) row.classList.add('on');
  renderPane(it);
}, 180);
function renderPane(it) {
  var pane = $('#pane'); if (!pane) return;
  if (!it) { pane.innerHTML = ''; return; }
  var fav = !!S.user.fav[it.key];
  pane.innerHTML = img(it.poster, it.name, 'logo', 'plogo') + '<h2>' + (it.num ? '<span style="color:var(--dim);font-variant-numeric:tabular-nums">' + it.num + '</span> ' : '') + esc(it.name) + '</h2><div id="epgbox"><p class="noepg">Carico la guida TV…</p></div>' +
    '<div class="actions"><button class="f btn pri" data-act="play-ch" data-key="' + esc(it.key) + '">' + IC.play + 'Guarda</button>' + (it.archive ? '<button class="f btn" data-act="catchup" data-key="' + esc(it.key) + '">' + IC.restart + 'Programmi passati</button>' : '') + '<button class="f btn" data-act="fav" data-key="' + esc(it.key) + '">' + (fav ? IC.star + 'Nei preferiti' : IC.starO + 'Aggiungi ai preferiti') + '</button></div>';
  getEpg(it).then(function (list) {
    if (S.live.sel !== it.key) return;
    var box = $('#epgbox'); if (!box) return;
    var now = Date.now(), cur = list[0] && list[0].s <= now ? list[0] : null, next = list.slice(cur ? 1 : 0, cur ? 4 : 3);
    if (!cur && !next.length) { box.innerHTML = '<p class="noepg">Guida TV non disponibile per questo canale.</p>'; return; }
    var html = '';
    if (cur) {
      var pc = Math.max(0, Math.min(100, (now - cur.s) / (cur.e - cur.s) * 100));
      html += '<p class="onair">In onda</p><p class="prog-t">' + esc(cur.t) + '</p><span class="prog-time">' + hhmm(cur.s) + ' – ' + hhmm(cur.e) + ' · mancano ' + Math.max(1, Math.round((cur.e - now) / 60000)) + ' min</span><div class="pbar"><i style="width:' + pc.toFixed(1) + '%"></i></div>' + (cur.d ? '<p class="desc">' + esc(cur.d) + '</p>' : '');
    }
    if (next.length) html += '<p class="eyebrow" style="margin-top:.6rem">A seguire</p><ul class="next">' + next.map(function (n) { return '<li><time>' + hhmm(n.s) + '</time><span>' + esc(n.t) + '</span></li>'; }).join('') + '</ul>';
    box.innerHTML = html;
    var row = stage.querySelector('.ch[data-key="' + it.key + '"] .nm');
    if (cur && row && !row.querySelector('.nowt')) row.insertAdjacentHTML('beforeend', '<span class="nowt">' + esc(cur.t) + '</span>');
  });
}
function nowTitle(key) { var c = S.epg[key], p = c && c.list[0]; return p && p.s <= Date.now() ? 'In onda: ' + p.t : ''; }
/* ---- guide grid ---- */
var gq = [], gActive = 0;
function guideWin() { var slot = 30 * 60000, a = Math.floor(Date.now() / slot) * slot; return { a: a, b: a + 3 * 3600e3 }; }
function pct(t, W) { return Math.max(0, Math.min(100, (t - W.a) / (W.b - W.a) * 100)); }
function nowLine(W) { return '<i class="g-nowline" style="left:' + pct(Date.now(), W).toFixed(2) + '%"></i>'; }
function guideRow(it, i, W) {
  return '<div class="g-row" data-key="' + esc(it.key) + '" data-ri="' + i + '"><div class="g-ch"><span class="num">' + (it.num || '') + '</span>' + img(it.poster, it.name, 'logo') + '<span class="nm">' + esc(it.name) + '</span></div>' +
    '<div class="g-line">' + nowLine(W) + '<button class="f g-cell now" data-act="g-cell" data-key="' + esc(it.key) + '" data-i="-1" style="left:0;width:100%"><b>Carico la guida…</b></button></div></div>';
}
function appendGuide() {
  var box = $('#grows'); if (!box || S.view !== 'live' || S.live.mode !== 'grid') return;
  var L = S.live, from = S.guideShown, to = Math.min(L.list.length, from + 30), W = S.guideW;
  if (from >= to) return;
  box.insertAdjacentHTML('beforeend', L.list.slice(from, to).map(function (it, k) { return guideRow(it, from + k, W); }).join(''));
  S.guideShown = to;
  L.list.slice(from, to).forEach(function (it) { gq.push(it); });
  pumpGuide();
}
function pumpGuide() {
  while (gActive < 4 && gq.length) {
    var it = gq.shift(); gActive++;
    fillGuideRow(it).then(doneGuide, doneGuide);
  }
}
function doneGuide() { gActive--; pumpGuide(); }
function fillGuideRow(it) {
  return getEpg(it).then(function (list) {
    var row = stage.querySelector('.g-row[data-key="' + cssq(it.key) + '"]'); if (!row) return;
    var W = S.guideW, now = Date.now(), line = row.querySelector('.g-line'), had = row.contains(document.activeElement);
    var cells = list.filter(function (p) { return p.e > W.a && p.s < W.b; }), html = nowLine(W);
    if (!cells.length) html += '<button class="f g-cell now" data-act="g-cell" data-key="' + esc(it.key) + '" data-i="-1" style="left:0;width:100%"><b>' + esc(it.name) + '</b><small>Guida non disponibile · premi per guardare</small></button>';
    else {
      if (cells[0].s > W.a + 60000) html += '<button class="f g-cell now" data-act="g-cell" data-key="' + esc(it.key) + '" data-i="-1" style="left:0;width:' + pct(cells[0].s, W).toFixed(2) + '%"><b>In onda</b></button>';
      cells.forEach(function (p, k) {
        var l = pct(p.s, W), r = pct(p.e, W);
        html += '<button class="f g-cell' + (p.s <= now && p.e > now ? ' now' : '') + '" data-act="g-cell" data-key="' + esc(it.key) + '" data-i="' + k + '" style="left:' + l.toFixed(2) + '%;width:' + (r - l).toFixed(2) + '%"><b>' + esc(p.t) + '</b><small>' + hhmm(p.s) + ' – ' + hhmm(p.e) + '</small></button>';
      });
    }
    line.innerHTML = html; row.__cells = cells;
    if (had) focusEl(line.querySelector('.g-cell.now') || line.querySelector('.g-cell'));
  });
}
function afterGuide(opts) {
  var W = S.guideW = guideWin();
  var r = $('#ruler'), h = '';
  for (var t = W.a; t < W.b; t += 30 * 60000) h += '<span style="left:' + pct(t, W).toFixed(2) + '%">' + hhmm(t) + '</span>';
  r.innerHTML = h;
  S.guideShown = 0; gq.length = 0;
  if (!S.live.list.length) { $('#grows').innerHTML = '<p class="noepg" style="padding:1rem">Nessun canale in questa categoria.</p>'; return; }
  appendGuide();
  if (!opts.noFocus && !opts.focusRail) { focusEl(stage.querySelector('.g-cell') || stage.querySelector('.lc.on')); return true; }
}

/* ---- catch-up ---- */
function loadArchive(it) {
  var s = src();
  if (s.type === 'demo') return Promise.resolve(demoArchive(it));
  return xapi(s, 'get_simple_data_table', { stream_id: it.id }).then(function (d) {
    var now = Date.now(), lim = now - Math.max(1, it.archiveDays || 3) * 864e5, raw = arr(d && d.epg_listings);
    var flagged = raw.some(function (e) { return e.has_archive != null; });
    return raw.filter(function (e) { var st = num(e.start_timestamp) * 1000, en = num(e.stop_timestamp) * 1000; return en < now && st > lim && (!flagged || String(e.has_archive) === '1'); })
      .map(function (e) { return { t: b64(e.title), d: b64(e.description), s: num(e.start_timestamp) * 1000, e: num(e.stop_timestamp) * 1000, start: String(e.start || '') }; })
      .sort(function (a, b) { return b.s - a.s; });
  }).catch(function (e) { return { err: e.message }; });
}
function dayLabel(t) {
  var d = new Date(t), today = new Date(); today.setHours(0, 0, 0, 0);
  var diff = Math.round((today - new Date(d.getFullYear(), d.getMonth(), d.getDate())) / 864e5);
  return diff === 0 ? 'Oggi' : diff === 1 ? 'Ieri' : d.toLocaleDateString('it-IT', { weekday: 'long', day: 'numeric', month: 'long' });
}
function openCatchup(key) {
  var it = S.idx[key]; if (!it) return;
  S.overlay = { type: 'catchup', key: key, prev: document.activeElement, list: null };
  $('#ov').hidden = false; renderOverlay(true);
  loadArchive(it).then(function (list) { if (!S.overlay || S.overlay.key !== key) return; S.overlay.list = list; renderOverlay(true); });
}
function renderCatchup(focus) {
  var o = S.overlay, it = S.idx[o.key], ov = $('#ov'), list = o.list, body = '';
  if (!list) body = '<p class="noepg">Carico l’archivio del canale…</p>';
  else if (list.err) body = '<div class="err">Archivio non disponibile: ' + esc(list.err) + '</div>';
  else if (!list.length) body = '<p class="noepg">Nessun programma registrato negli ultimi giorni.</p>';
  else {
    var day = '';
    list.forEach(function (e, i) {
      var dl = dayLabel(e.s);
      if (dl !== day) { body += '<p class="eyebrow" style="margin:1.4rem 0 .3rem">' + esc(dl) + '</p>'; day = dl; }
      body += '<button class="f ep" data-act="cu-play" data-i="' + i + '"><span class="tx"><b>' + esc(e.t || 'Senza titolo') + '</b><span class="em">' + hhmm(e.s) + ' – ' + hhmm(e.e) + ' · ' + Math.round((e.e - e.s) / 60000) + ' min</span>' + (e.d ? '<p>' + esc(e.d) + '</p>' : '') + '</span></button>';
    });
  }
  ov.innerHTML = '<div class="ov-body"><div style="max-width:62rem">' + img(it.poster, it.name, 'logo', 'plogo') + '<p class="eyebrow" style="margin-top:1rem">Programmi passati</p><h1 class="ov-title" style="font-size:2.6rem">' + esc(it.name) + '</h1><p class="noepg">Riguarda i programmi degli ultimi ' + Math.max(1, it.archiveDays || 3) + ' giorni. Puoi mettere in pausa e andare avanti e indietro.</p><div class="eps">' + body + '</div></div></div>';
  if (focus || !ov.contains(document.activeElement)) focusEl(ov.querySelector('.ep') || ov.querySelector('.f'));
}
function fmtStamp(t) { var d = new Date(t); return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()) + ':' + pad2(d.getHours()) + '-' + pad2(d.getMinutes()); }
function playCatchup(i) {
  var o = S.overlay, it = S.idx[o.key], e = o.list[i], s = src(); if (!e) return;
  var dur = Math.max(1, Math.round((e.e - e.s) / 60000));
  var stamp = e.start ? e.start.replace(/^(\d{4}-\d{2}-\d{2})[ T](\d{2}):(\d{2}).*$/, '$1:$2-$3') : fmtStamp(e.s);
  var url = s.type === 'xtream' ? s.server + '/timeshift/' + pathSafe(s.user) + '/' + pathSafe(s.pass) + '/' + dur + '/' + stamp + '/' + it.id + '.ts' : 'demo://catchup';
  startPlayback([{ key: 'c' + it.id + '_' + e.s, kind: 'catchup', id: it.id, name: e.t || it.name, sub: it.name + ' · ' + dayLabel(e.s) + ' ' + hhmm(e.s), url: url, poster: it.poster }], 0, false, 0);
}

function playChannel(key) {
  var it = S.idx[key] || (S.user.fav[key]) || (S.user.plays[key] && S.user.plays[key].item); if (!it) return;
  var list = S.view === 'live' && S.live.list.length ? S.live.list : liveList(it.cat), i = 0;
  for (var k = 0; k < list.length; k++) if (list[k].key === key) { i = k; break; }
  if (list[i] && list[i].key !== key) { list = [it]; i = 0; }
  var from = Math.max(0, i - 150), slice = list.slice(from, from + 300);
  startPlayback(slice.map(function (c) { var sn = snapOf(c); sn.sub = nowTitle(c.key); return sn; }), i - from, true, 0);
}

/* ---- search ---- */
VIEWS.search = function () {
  return '<div class="form" style="max-width:none;padding-bottom:.4rem"><h1>Cerca</h1><div class="field"><label for="q">Titolo di film, serie o canale</label><input id="q" class="f inp" type="search" autocomplete="off" placeholder="Per esempio: Matera" value="' + esc(S.query) + '"></div></div><div id="results"></div>';
};
function runSearch() {
  var q = norm(S.query).trim(), box = $('#results'); if (!box) return;
  if (q.length < 2) { box.innerHTML = '<p class="empty" style="padding-top:1rem">Scrivi almeno due lettere. La ricerca guarda film, serie TV e canali insieme.</p>'; return; }
  var terms = q.split(/\s+/);
  function hit(it) { var n = it._n || (it._n = norm(it.name)); for (var i = 0; i < terms.length; i++) if (n.indexOf(terms[i]) < 0) return false; return true; }
  var mv = S.V.movie.filter(hit).slice(0, 60), se = S.V.series.filter(hit).slice(0, 60), ch = S.V.live.filter(hit).slice(0, 40);
  if (!mv.length && !se.length && !ch.length) { box.innerHTML = '<p class="empty" style="padding-top:1rem">Nessun risultato per «' + esc(S.query) + '».</p>'; return; }
  box.innerHTML = (mv.length ? '<h2 class="sub">Film · ' + mv.length + '</h2><div class="grid">' + mv.map(function (x) { return posterCard(x); }).join('') + '</div>' : '') +
    (se.length ? '<h2 class="sub">Serie TV · ' + se.length + '</h2><div class="grid">' + se.map(function (x) { return posterCard(x); }).join('') + '</div>' : '') +
    (ch.length ? '<h2 class="sub">Canali · ' + ch.length + '</h2><div class="grid chans">' + ch.map(chanCard).join('') + '</div>' : '');
}
AFTER.search = function (opts) {
  var q = $('#q');
  q.addEventListener('input', debounce(function () { S.query = q.value; runSearch(); }, 250));
  runSearch();
  if (!opts.noFocus && !opts.focusRail) { focusEl(q); return true; }
};

/* ---- my list ---- */
VIEWS.mylist = function () {
  var t = favs(['movie', 'series']), c = favs(['live']);
  if (!t.length && !c.length) return '<div class="vhead"><h1>La mia lista</h1></div><div class="empty"><h2>La lista è vuota</h2><p>Apri un film o una serie e scegli «La mia lista» per ritrovarli qui. Per i canali usa «Aggiungi ai preferiti» nella sezione In diretta.</p></div>';
  return '<div class="vhead"><h1>La mia lista</h1><span class="count">' + (t.length + c.length) + ' elementi</span></div>' +
    (t.length ? '<div class="grid">' + t.map(function (x) { return posterCard(x); }).join('') + '</div>' : '') +
    (c.length ? '<h2 class="sub">Canali preferiti</h2><div class="grid chans">' + c.map(chanCard).join('') + '</div>' : '');
};

/* ---- settings ---- */
function expText(a) {
  if (!a) return '';
  var e = num(a.exp);
  return e ? new Date(e * 1000).toLocaleDateString('it-IT', { day: 'numeric', month: 'long', year: 'numeric' }) : 'Nessuna scadenza indicata';
}
function chips(key, opts) {
  return opts.map(function (o) { var on = String(S.settings[key]) === String(o[0]) || (typeof S.settings[key] === 'boolean' && S.settings[key] === (o[0] === '1')); return '<button class="f chip' + (on ? ' on' : '') + '" data-act="set" data-key="' + key + '" data-v="' + o[0] + '">' + o[1] + '</button>'; }).join('');
}
function optRow(label, key, opts, note) { return '<div class="row"><span class="noepg" style="min-width:11rem">' + label + '</span>' + chips(key, opts) + '</div>' + (note ? '<p class="noepg" style="margin:0">' + note + '</p>' : ''); }
VIEWS.settings = function () {
  var s = src(), a = S.D && S.D.account, st = S.settings;
  var rows = S.sources.map(function (x) {
    var on = x.id === S.activeId, kind = x.type === 'xtream' ? 'Xtream Codes · ' + esc(x.server) : x.type === 'm3u' ? 'Link M3U' : 'Dati dimostrativi';
    return '<div class="srcrow"><div class="who"><b>' + esc(x.name) + '</b>' + (on ? '<span class="pill">In uso</span>' : '') + '<span>' + kind + '</span></div>' +
      (on ? '' : '<button class="f btn sm" data-act="use-src" data-key="' + x.id + '">Usa questa</button>') +
      (x.type === 'demo' ? '' : '<button class="f btn sm" data-act="edit-src" data-key="' + x.id + '">Modifica</button>') +
      '<button class="f btn sm danger" data-act="del-src" data-key="' + x.id + '">Elimina</button></div>';
  }).join('');
  var acc = '';
  if (a && s && s.type !== 'm3u') {
    var ok = a.status === 'Active';
    acc = '<section><h2>Abbonamento</h2><dl class="kv"><dt>Stato</dt><dd class="' + (ok ? 'okc' : 'badc') + '">' + (ok ? 'Attivo' : esc(a.status || 'Sconosciuto')) + (String(a.trial) === '1' ? ' (prova)' : '') + '</dd><dt>Scadenza</dt><dd>' + esc(expText(a)) + '</dd><dt>Connessioni</dt><dd>' + esc(a.active != null ? a.active : '–') + ' in uso su ' + esc(a.max || '–') + '</dd>' +
      (S.D.ts ? '<dt>Catalogo</dt><dd>aggiornato il ' + new Date(S.D.ts).toLocaleString('it-IT', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) + '</dd>' : '') + '</dl></section>';
  }
  var counts = S.V ? S.V.movie.length + ' film · ' + S.V.series.length + ' serie · ' + S.V.live.length + ' canali' : '';
  return '<div class="settings"><div><h1 class="lhead" style="margin:0;font-size:2.3rem">Impostazioni</h1>' + (counts ? '<p class="noepg" style="margin:.5rem 0 0">' + counts + '</p>' : '') + '</div>' +
    '<section><h2>Playlist</h2>' + rows + '<div class="row"><button class="f btn" data-act="add-src">' + IC.plus + 'Aggiungi playlist</button></div></section>' + acc +
    '<section><h2>Lettore</h2>' +
      optRow('Buffer', 'buffer', [['standard', 'Standard'], ['large', 'Ampio'], ['max', 'Massimo']], 'Se i canali si fermano a caricare, aumenta il buffer: l’avvio diventa un po’ più lento ma le interruzioni calano.') +
      optRow('Lettore video', 'player', [['internal', 'Integrato'], ['external', 'Esterno (VLC, MX…)']], 'Usa il lettore esterno per i video che il Firestick non riesce a decodificare. Il punto di visione in quel caso non viene salvato.') +
      optRow('All’avvio', 'startLast', [['0', 'Mostra la Home'], ['1', 'Riprendi l’ultimo canale']]) +
      optRow('Formato diretta', 'liveFormat', [['ts', 'MPEG-TS (.ts)'], ['hls', 'HLS (.m3u8)']], 'Se un canale si blocca o non parte, prova l’altro formato.') + '</section>' +
    '<section><h2>Audio e sottotitoli</h2>' +
      optRow('Lingua audio', 'audioLang', [['it', 'Italiano'], ['en', 'Inglese'], ['', 'Originale']]) +
      optRow('Sottotitoli', 'subLang', [['off', 'Disattivati'], ['it', 'Italiano'], ['en', 'Inglese']]) +
      optRow('Dimensione', 'subSize', [['s', 'Piccoli'], ['m', 'Normali'], ['l', 'Grandi'], ['xl', 'Molto grandi']]) +
      optRow('Sfondo', 'subBg', [['0', 'Trasparente'], ['1', 'Riquadro scuro']], 'Durante la visione puoi cambiare traccia audio, sottotitoli e velocità dall’icona impostazioni del lettore (premi il tasto centrale).') + '</section>' +
    '<section><h2>Contenuti e controllo parentale</h2>' +
      optRow('Contenuti per adulti', 'hideAdult', [['1', 'Nascosti'], ['0', 'Visibili']], st.pin ? 'Per renderli visibili serve il PIN.' : 'Imposta un PIN per proteggere questa scelta.') +
      '<div class="row"><button class="f btn" data-act="set-pin">' + (st.pin ? 'Cambia PIN' : 'Imposta PIN') + '</button>' + (st.pin ? '<button class="f btn" data-act="del-pin">Rimuovi PIN</button>' : '') + '<button class="f btn" data-act="open-cats">Nascondi categorie</button></div>' +
      '<div class="row"><button class="f btn" data-act="reload">' + IC.restart + 'Aggiorna il catalogo adesso</button><button class="f btn danger" data-act="clear-hist">Cancella cronologia di visione</button></div></section>' +
    '<section><h2>Trame e voti da TMDB e OMDb</h2>' +
      '<div class="field"><label for="tmdb">Chiave API TMDB (v3) o token di lettura</label><input id="tmdb" class="f inp" type="text" autocomplete="off" autocapitalize="off" placeholder="Incolla la chiave da themoviedb.org → Impostazioni → API" value="' + esc(st.tmdbKey) + '"><small>Attiva trame in italiano, locandine, cast e le righe Top 10 e Di tendenza.</small></div>' +
      '<div class="field"><label for="omdb">Chiave OMDb (facoltativa)</label><input id="omdb" class="f inp" type="text" autocomplete="off" autocapitalize="off" placeholder="Chiave gratuita da omdbapi.com" value="' + esc(st.omdbKey) + '"><small>Aggiunge i voti IMDb, Rotten Tomatoes e Metacritic nella scheda dei film.</small></div>' +
      '<div class="row"><button class="f btn" data-act="save-keys">' + IC.check + 'Salva e verifica</button></div>' +
      optRow('Trame', 'preferTmdb', [['0', 'Del fornitore'], ['1', 'Sempre da TMDB']]) +
      '<p class="credit">Questo prodotto usa l’API di TMDB ma non è approvato né certificato da TMDB (This product uses the TMDB API but is not endorsed or certified by TMDB). Voti IMDb, Rotten Tomatoes e Metacritic forniti da OMDb API (CC BY-NC 4.0).</p></section>' +
    '<section><h2>Connessione</h2><div class="field"><label for="ua">User-Agent personalizzato</label><div class="row"><input id="ua" class="f inp" type="text" autocomplete="off" placeholder="Lascia vuoto per quello predefinito" value="' + esc(st.ua) + '"><button class="f btn sm" data-act="save-ua">Salva</button></div><small>Serve solo se il fornitore accetta esclusivamente determinate app.</small></div></section>' +
    '<p class="noepg">Orbita TV ' + (NATIVE ? esc(window.OrbitaNative.version()) : 'anteprima web') + ' · Nel lettore il tasto Menu cambia il formato dell’immagine.</p></div>';
};

/* ---- hidden categories ---- */
VIEWS.cats = function () {
  var k = S.catsKind, h = S.user.hidden[k] || {}, all = (S.D && S.D.cats[k]) || [];
  var list = all.filter(function (c) { return !(S.settings.hideAdult && ADULT.test(c.name)); });
  var n = {}; (S.D[k] || []).forEach(function (it) { n[it.cat] = (n[it.cat] || 0) + 1; });
  var tabs = [['live', 'Canali'], ['movie', 'Film'], ['series', 'Serie TV']].map(function (t) { return '<button class="f chip' + (k === t[0] ? ' on' : '') + '" data-act="cats-kind" data-v="' + t[0] + '">' + t[1] + '</button>'; }).join('');
  var hiddenN = Object.keys(h).filter(function (x) { return h[x]; }).length;
  return '<div class="vhead"><h1>Categorie</h1><span class="count">' + hiddenN + ' nascoste</span><div class="sorts">' + tabs + '</div></div>' +
    '<p class="noepg" style="padding:0 var(--gut) 0 1.5rem">Premi su una categoria per nasconderla o mostrarla. Le categorie nascoste spariscono da Home, griglie, ricerca e diretta.</p>' +
    (hiddenN ? '<div class="row" style="padding:.8rem var(--gut) 0 1.5rem"><button class="f btn sm" data-act="show-all-cats">Mostra tutte</button></div>' : '') +
    '<div class="catgrid">' + list.map(function (c) { var off = !!h[c.id]; return '<button class="f lc' + (off ? ' off' : '') + '" data-act="toggle-cat" data-key="' + esc(c.id) + '"><span>' + esc(c.name) + '</span><small>' + (off ? 'Nascosta' : (n[c.id] || 0)) + '</small></button>'; }).join('') + '</div>';
};

/* ---- PIN modal ---- */
function askPin(title, msg, cb) {
  S.modal = { title: title, msg: msg, entered: '', cb: cb, prev: S.modal ? S.modal.prev : document.activeElement };
  renderModal(); focusEl($('#modal [data-v="1"]'));
}
function renderModal(keep) {
  var m = S.modal, el = $('#modal');
  if (!m) { el.hidden = true; el.innerHTML = ''; return; }
  el.hidden = false;
  el.innerHTML = '<div class="pinbox" role="dialog" aria-label="' + esc(m.title) + '"><h2>' + esc(m.title) + '</h2><p class="noepg" style="margin:0">' + esc(m.msg) + '</p><div class="pindots">' + [0, 1, 2, 3].map(function (i) { return '<i class="' + (i < m.entered.length ? 'on' : '') + '"></i>'; }).join('') + '</div><div class="pinpad">' +
    ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'del', '0', 'esc'].map(function (d) { return '<button class="f btn" data-act="pin-key" data-v="' + d + '">' + (d === 'del' ? 'Canc' : d === 'esc' ? 'Annulla' : d) + '</button>'; }).join('') + '</div></div>';
  if (keep) focusEl(el.querySelector('[data-v="' + keep + '"]'));
}
function closeModal() {
  var m = S.modal; S.modal = null; renderModal();
  if (m && m.prev && document.contains(m.prev)) focusEl(m.prev); else focusFirst();
}
function pinKey(d) {
  var m = S.modal; if (!m) return;
  if (d === 'esc') { closeModal(); return; }
  if (d === 'del') m.entered = m.entered.slice(0, -1);
  else if (m.entered.length < 4) m.entered += d;
  if (m.entered.length === 4) {
    var code = m.entered, res = m.cb(code);
    if (res === true) {
      if (S.modal === m) {
        S.modal = null; renderModal();
        var a = document.activeElement;
        if (!a || a === document.body || !document.contains(a)) { if (m.prev && document.contains(m.prev)) focusEl(m.prev); else focusFirst(); }
      }
      return;
    }
    m.msg = res; m.entered = '';
  }
  renderModal(d);
}
function changePin() {
  function choose() {
    askPin('Nuovo PIN', 'Scegli 4 cifre da ricordare.', function (a) {
      askPin('Conferma il PIN', 'Inserisci di nuovo le stesse 4 cifre.', function (b) {
        if (a !== b) return 'I due PIN non coincidono. Ricomincia da capo.';
        S.settings.pin = a; saveSettings(); toast('PIN salvato.');
        S.modal = null; renderModal(); go('settings', { focusSel: '[data-act="set-pin"]' });
        return true;
      });
      return true;
    });
  }
  if (S.settings.pin) askPin('PIN attuale', 'Inserisci il PIN attuale.', function (c) { if (c !== S.settings.pin) return 'PIN errato, riprova.'; choose(); return true; });
  else choose();
}

/* ---- setup form ---- */
function formFrom(s) { return s ? { id: s.id, type: s.type === 'demo' ? 'xtream' : s.type, name: s.name, server: s.server || '', user: s.user || '', pass: s.pass || '', m3u: s.m3u || '', epg: s.epg || '', err: '' } : { type: 'xtream', err: '' }; }
VIEWS.setup = function () {
  var f = S.form || { type: 'xtream' }, x = f.type === 'xtream';
  return '<div class="form">' + (f.first ? '<p class="eyebrow">Benvenuto</p><h1>Collega la tua playlist</h1><p class="lead">Inserisci i dati che ti ha dato il fornitore. Con un account Xtream Codes ottieni locandine, trame, voti e guida TV; con un link M3U i contenuti vengono ordinati per categoria.</p>' : '<h1>' + (f.id ? 'Modifica playlist' : 'Nuova playlist') + '</h1>') +
    (f.err ? '<div class="err" role="alert">' + esc(f.err) + '</div>' : '') +
    (!NATIVE ? '<div class="note">Questa è l’anteprima web: i server IPTV non sono raggiungibili dal browser. Per vedere l’interfaccia usa i dati dimostrativi; i tuoi dati vanno inseriti nell’app sul Firestick.</div>' : '') +
    '<div class="field"><label>Tipo di playlist</label><div class="seg"><button class="f chip' + (x ? ' on' : '') + '" data-act="ftype" data-v="xtream">Xtream Codes</button><button class="f chip' + (!x ? ' on' : '') + '" data-act="ftype" data-v="m3u">Link M3U</button></div></div>' +
    '<div class="field"><label for="f-name">Nome</label><input id="f-name" class="f inp" type="text" autocomplete="off" placeholder="Per esempio: Casa" value="' + esc(f.name || '') + '"></div>' +
    (x ? '<div class="field"><label for="f-server">Indirizzo del server</label><input id="f-server" class="f inp" type="url" autocomplete="off" placeholder="http://dominio.com:8080" value="' + esc(f.server || '') + '"><small>Puoi incollare anche il link completo M3U (quello con username e password): i campi qui sotto si compilano da soli.</small></div>' +
      '<div class="field"><label for="f-user">Nome utente</label><input id="f-user" class="f inp" type="text" autocomplete="off" autocapitalize="off" value="' + esc(f.user || '') + '"></div>' +
      '<div class="field"><label for="f-pass">Password</label><input id="f-pass" class="f inp" type="text" autocomplete="off" autocapitalize="off" value="' + esc(f.pass || '') + '"></div>'
      : '<div class="field"><label for="f-m3u">Link della playlist M3U</label><input id="f-m3u" class="f inp" type="url" autocomplete="off" placeholder="http://…/get.php?username=…&amp;password=…&amp;type=m3u_plus" value="' + esc(f.m3u || '') + '"></div>' +
      '<div class="field"><label for="f-epg">Link della guida TV (XMLTV, facoltativo)</label><input id="f-epg" class="f inp" type="url" autocomplete="off" placeholder="http://…/xmltv.php" value="' + esc(f.epg || '') + '"><small>Se la playlist indica già la sua guida TV, puoi lasciarlo vuoto.</small></div>') +
    '<div class="actions"><button class="f btn pri" data-act="save-src">' + IC.check + 'Salva e carica</button>' + (f.first || !NATIVE ? '<button class="f btn" data-act="demo">Prova con dati dimostrativi</button>' : '') + (src() && S.D ? '<button class="f btn" data-act="nav" data-v="settings">Annulla</button>' : '') + '</div></div>';
};
AFTER.setup = function () {
  var sv = $('#f-server');
  if (sv) sv.addEventListener('input', function () { var p = parseServer(sv.value); if (p.user && !$('#f-user').value) $('#f-user').value = p.user; if (p.pass && !$('#f-pass').value) $('#f-pass').value = p.pass; });
};
function readForm() {
  var f = S.form || {};
  ['name', 'server', 'user', 'pass', 'm3u', 'epg'].forEach(function (k) { var el = $('#f-' + k); if (el) f[k] = el.value; });
  S.form = f; return f;
}
function saveSource() {
  var f = readForm(), s = { id: f.id || ('p' + Date.now().toString(36)), type: f.type, name: (f.name || '').trim() };
  if (f.type === 'xtream') {
    var p = parseServer(f.server);
    s.server = p.server; s.user = (f.user || p.user || '').trim(); s.pass = f.pass || p.pass || '';
    if (!s.server || !s.user || !s.pass) { f.err = 'Compila indirizzo del server, nome utente e password.'; go('setup'); return; }
  } else {
    s.m3u = (f.m3u || '').trim(); s.epg = (f.epg || '').trim();
    if (!/^https?:\/\//i.test(s.m3u)) { f.err = 'Inserisci un link che inizi con http:// o https://.'; go('setup'); return; }
    var g = s.m3u.match(/^(https?:\/\/[^?#]+?)\/get\.php\?(.*)$/i);
    if (g) {
      var q = {}; g[2].split('&').forEach(function (kv) { var i = kv.indexOf('='); if (i > 0) { try { q[kv.slice(0, i)] = decodeURIComponent(kv.slice(i + 1)); } catch (e) { q[kv.slice(0, i)] = kv.slice(i + 1); } } });
      if (q.username && q.password) { s = { id: s.id, type: 'xtream', name: s.name, server: g[1], user: q.username, pass: q.password }; toast('Il link appartiene a un account Xtream: uso le sue API per avere locandine, voti e guida TV.'); }
    }
  }
  if (!s.name) s.name = s.type === 'xtream' ? 'Xtream' : 'Playlist M3U';
  var found = false;
  S.sources = S.sources.map(function (x) { if (x.id === s.id) { found = true; return s; } return x; });
  if (!found) S.sources.push(s);
  S.activeId = s.id; saveSources();
  start(true);
}

/* ================= detail overlay ================= */
function loadDetails(it) {
  if (it._loaded) return Promise.resolve(it);
  var s = src();
  if (!s || s.type !== 'xtream') { it._loaded = true; return Promise.resolve(it); }
  var p = it.kind === 'movie' ? xapi(s, 'get_vod_info', { vod_id: it.id }).then(function (d) { xMovieInfo(it, d); }) : xapi(s, 'get_series_info', { series_id: it.id }).then(function (d) { xSeriesInfo(it, d); });
  return p.then(function () { it._loaded = true; return it; }, function (e) { it._err = e.message; return it; });
}
function openDetail(key) {
  var it = S.idx[key] || (S.user.fav[key]) || (S.user.plays[key] && S.user.plays[key].item);
  if (!it) { toast('Questo titolo non è più nel catalogo.'); return; }
  if (it.kind === 'live') { playChannel(it.key); return; }
  stopHero();
  S.overlay = { key: it.key, prev: document.activeElement, season: 0 };
  $('#ov').hidden = false;
  renderOverlay(true);
  loadDetails(it).then(function () {
    if (!S.overlay || S.overlay.key !== it.key) return;
    if (it.kind === 'series' && it.seasonList) { var le = S.user.lastEp[it.key]; if (le) it.seasonList.forEach(function (s, i) { s.eps.forEach(function (e) { if (e.key === le.key) S.overlay.season = i; }); }); }
    renderOverlay(true);
    if (!tmdbOn()) return;
    S.overlay.metaLoading = !it.meta;
    getMeta(it).then(function (m) {
      applyMeta(it, m);
      if (S.overlay && S.overlay.key === it.key) { S.overlay.metaLoading = false; renderOverlay(); }
    }, function (e) { if (S.overlay) S.overlay.metaLoading = false; toast(e.message); });
  });
}
function closeOverlay() {
  var prev = S.overlay && S.overlay.prev;
  S.overlay = null; $('#ov').hidden = true; $('#ov').innerHTML = '';
  if (S.view === 'home') { refresh(prev && document.contains(prev) ? prev : null); }
  else if (prev && document.contains(prev)) focusEl(prev); else focusFirst();
}
function nextEpisode(it) {
  var le = S.user.lastEp[it.key], sl = it.seasonList || [];
  if (!sl.length) return null;
  if (le) for (var i = 0; i < sl.length; i++) for (var j = 0; j < sl[i].eps.length; j++) if (sl[i].eps[j].key === le.key) {
    if (S.user.watched[le.key] && !S.user.prog[le.key]) { if (j + 1 < sl[i].eps.length) return { s: i, e: j + 1, resume: false }; if (i + 1 < sl.length) return { s: i + 1, e: 0, resume: false }; }
    return { s: i, e: j, resume: !!S.user.prog[le.key] };
  }
  return { s: 0, e: 0, resume: false };
}
function renderOverlay(focus) {
  var o = S.overlay; if (!o) return;
  if (o.type === 'catchup') { renderCatchup(focus); return; }
  var it = S.idx[o.key] || S.user.fav[o.key] || (S.user.plays[o.key] && S.user.plays[o.key].item), ov = $('#ov');
  var a = document.activeElement, keepSel = !focus && a && ov.contains(a) ? '[data-act="' + a.getAttribute('data-act') + '"]' + (a.getAttribute('data-e') ? '[data-e="' + a.getAttribute('data-e') + '"]' : '') : null;
  var bd = it.backdrop, inList = !!S.user.fav[it.key], cat = catName(it.kind, it.cat), loading = !it._loaded && !it._err;
  var btns = '';
  if (it.kind === 'movie') {
    var p = S.user.prog[it.key];
    btns = (p ? '<button class="f btn pri" data-act="play-movie" data-key="' + esc(it.key) + '" data-v="resume">' + IC.play + 'Riprendi da ' + fmtClock(p.pos) + '</button><button class="f btn" data-act="play-movie" data-key="' + esc(it.key) + '">' + IC.restart + 'Dall’inizio</button>'
      : '<button class="f btn pri" data-act="play-movie" data-key="' + esc(it.key) + '">' + IC.play + 'Guarda</button>');
  } else if (it.seasonList && it.seasonList.length) {
    var nx = nextEpisode(it), ss = it.seasonList[nx.s], ee = ss.eps[nx.e];
    btns = '<button class="f btn pri" data-act="play-ep" data-s="' + nx.s + '" data-e="' + nx.e + '">' + IC.play + (nx.resume ? 'Riprendi' : 'Guarda') + ' S' + ss.n + ' · E' + ee.num + '</button>';
  }
  btns += '<button class="f btn" data-act="fav" data-key="' + esc(it.key) + '">' + (inList ? IC.check + 'Nella lista' : IC.plus + 'La mia lista') + '</button>';
  var credits = (it.director ? '<dt>Regia</dt><dd>' + esc(it.director) + '</dd>' : '') + (it.cast ? '<dt>Cast</dt><dd>' + esc(String(it.cast).split(',').slice(0, 6).join(', ')) + '</dd>' : '');
  var html = '<div class="ov-bg' + (bd ? '' : ' soft') + '" style="background-image:url(&quot;' + esc(bd || it.poster || fallbackFor(it.name, 'poster')) + '&quot;)"></div><div class="ov-shade"></div><div class="ov-body"><div class="ov-main">' +
    '<p class="eyebrow">' + (it.kind === 'series' ? 'Serie TV' : 'Film') + (cat ? ' · ' + esc(cat) : '') + '</p><h1 class="ov-title">' + esc(dispName(it.name)) + '</h1>' + metaLine(it) + (it.meta && it.meta.tagline ? '<p class="tagline">' + esc(it.meta.tagline) + '</p>' : '') +
    (it.plot ? '<p class="plot">' + esc(it.plot) + '</p>' : loading ? '<p class="plot">Carico trama e dettagli…</p>' : '') +
    scoresHtml(it) +
    (credits ? '<dl class="credits">' + credits + '</dl>' : '') + (it._err ? '<p class="noepg">Dettagli non disponibili: ' + esc(it._err) + '</p>' : '') +
    '<div class="actions">' + btns + '</div></div>';
  if (it.kind === 'series' && it.seasonList && it.seasonList.length) {
    var si = Math.min(o.season, it.seasonList.length - 1), season = it.seasonList[si];
    html += (it.seasonList.length > 1 ? '<div class="track chips seasons">' + it.seasonList.map(function (s, i) { return '<button class="f chip' + (i === si ? ' on' : '') + '" data-act="season" data-v="' + i + '">Stagione ' + s.n + '</button>'; }).join('') + '</div>' : '<p class="eyebrow" style="margin-top:1.8rem">Stagione ' + season.n + '</p>') +
      '<div class="eps">' + season.eps.map(function (e, j) {
        var pr = progOf(e.key), seen = S.user.watched[e.key] && !pr;
        return '<button class="f ep" data-act="play-ep" data-s="' + si + '" data-e="' + j + '"><span class="th">' + img(e.thumb || it.backdrop || it.poster, it.name, e.thumb || it.backdrop ? 'wide' : 'poster') + (pr ? '<span class="bar"><i style="width:' + pr + '%"></i></span>' : '') + '</span>' +
          '<span class="tx"><b>' + e.num + '. ' + esc(e.title || 'Episodio ' + e.num) + '</b><span class="em">' + (e.dur ? fmtDur(e.dur) : '') + (seen ? (e.dur ? ' · ' : '') + '<span class="seen">Visto</span>' : '') + (pr ? (e.dur ? ' · ' : '') + 'In corso' : '') + '</span>' + (e.plot ? '<p>' + esc(e.plot) + '</p>' : '') + '</span></button>';
      }).join('') + '</div>';
  } else if (it.kind === 'series' && loading) html += '<p class="noepg" style="margin-top:2rem">Carico stagioni ed episodi…</p>';
  html += '</div>';
  ov.innerHTML = html;
  if (keepSel && ov.querySelector(keepSel)) focusEl(ov.querySelector(keepSel));
  else if (focus || !ov.contains(document.activeElement)) focusEl(ov.querySelector('.btn.pri') || ov.querySelector('.f'));
}
function playMovie(key, resume) {
  var it = S.idx[key] || S.user.fav[key]; if (!it) return;
  var p = S.user.prog[key];
  startPlayback([snapOf(it)], 0, false, resume && p ? p.pos : 0);
}
function playEpisode(si, ei) {
  var it = S.idx[S.overlay.key]; if (!it || !it.seasonList) return;
  var season = it.seasonList[si], rest = season.eps.slice(ei), snaps = rest.map(function (e) { return epSnap(it, season, e); });
  var p = S.user.prog[snaps[0].key];
  startPlayback(snaps, 0, false, p ? p.pos : 0);
}

/* ================= actions ================= */
function toggleFav(key) {
  var it = S.idx[key] || S.user.fav[key]; if (!it) return;
  if (S.user.fav[key]) { delete S.user.fav[key]; toast('Rimosso da ' + (it.kind === 'live' ? 'preferiti' : 'La mia lista') + '.'); }
  else { S.user.fav[key] = snapOf(it); toast('Aggiunto a ' + (it.kind === 'live' ? 'preferiti' : 'La mia lista') + '.'); }
  saveUser();
}
var BOOLS = ['hideAdult', 'subBg', 'preferTmdb', 'startLast'];
var ACT = {
  nav: function (el) { var v = el.getAttribute('data-v'); if (S.overlay) closeOverlay(); go(v); },
  open: function (el) { openDetail(el.getAttribute('data-key')); },
  resume: function (el) {
    var p = S.user.prog[el.getAttribute('data-key')]; if (!p) return;
    startPlayback([p.item], 0, false, p.pos);
  },
  'hero-play': function (el) {
    var it = S.idx[el.getAttribute('data-key')]; if (!it) return;
    if (it.kind === 'movie') { playMovie(it.key, true); return; }
    openDetail(it.key);
  },
  fav: function (el) {
    var key = el.getAttribute('data-key'); toggleFav(key);
    if (S.overlay) renderOverlay();
    else if (S.view === 'live') { var it = S.idx[key]; renderPane(it); var b = $('#pane [data-act="fav"]'); if (b) focusEl(b); var row = stage.querySelector('.ch[data-key="' + key + '"]'); if (row) row.outerHTML = chRow(it, +row.getAttribute('data-li')); }
    else if (S.view === 'home') renderHero(true);
    else refresh();
  },
  'see-all': function (el) {
    var k = el.getAttribute('data-kind'); S.grid[k].cat = el.getAttribute('data-cat'); S.grid[k].sort = el.getAttribute('data-sort') || 'recent';
    go(k, { focusSel: '.chip.on[data-act="cat"]' });
  },
  cat: function (el) { var k = el.getAttribute('data-kind'); S.grid[k].cat = el.getAttribute('data-key'); go(k, { focusSel: '[data-act="cat"][data-key="' + cssq(S.grid[k].cat) + '"]' }); },
  sort: function (el) { var k = el.getAttribute('data-kind'); S.grid[k].sort = el.getAttribute('data-v'); go(k, { focusSel: '[data-act="sort"][data-v="' + S.grid[k].sort + '"]' }); },
  'live-cat': function (el) { S.live.cat = el.getAttribute('data-key'); S.live.sel = null; go('live', { noFocus: true }); focusEl(stage.querySelector('.lc.on')); },
  'live-ch': function (el) { playChannel(el.getAttribute('data-key')); },
  'play-ch': function (el) { playChannel(el.getAttribute('data-key')); },
  'play-movie': function (el) { playMovie(el.getAttribute('data-key'), el.getAttribute('data-v') === 'resume'); },
  'play-ep': function (el) { playEpisode(+el.getAttribute('data-s'), +el.getAttribute('data-e')); },
  season: function (el) { S.overlay.season = +el.getAttribute('data-v'); renderOverlay(); focusEl($('#ov [data-act="season"][data-v="' + S.overlay.season + '"]')); },
  set: function (el) {
    var k = el.getAttribute('data-key'), v = el.getAttribute('data-v'), val = BOOLS.indexOf(k) >= 0 ? v === '1' : v;
    var sel = '[data-act="set"][data-key="' + k + '"][data-v="' + v + '"]';
    function apply() {
      S.settings[k] = val; saveSettings();
      if (k === 'hideAdult' && S.D) buildView();
      if (k === 'preferTmdb') META.mem = {};
      S.modal = null; renderModal();
      go('settings', { focusSel: sel });
    }
    if (k === 'hideAdult' && val === false && S.settings.pin && S.settings.hideAdult) {
      askPin('PIN richiesto', 'Inserisci il PIN per mostrare i contenuti per adulti.', function (c) { if (c !== S.settings.pin) return 'PIN errato, riprova.'; apply(); return true; });
      return;
    }
    apply();
  },
  'live-mode': function (el) { S.live.mode = el.getAttribute('data-v'); go('live', { noFocus: true }); focusEl(stage.querySelector('[data-act="live-mode"].on')); },
  catchup: function (el) { openCatchup(el.getAttribute('data-key')); },
  'cu-play': function (el) { playCatchup(+el.getAttribute('data-i')); },
  'g-cell': function (el) {
    var row = el.closest('.g-row'), key = el.getAttribute('data-key'), i = +el.getAttribute('data-i'), p = row && row.__cells && row.__cells[i];
    if (!p || p.s <= Date.now()) { playChannel(key); return; }
    toast('«' + p.t + '» inizia alle ' + hhmm(p.s) + '.' + (p.d ? ' ' + p.d.slice(0, 160) : ''));
  },
  'pin-key': function (el) { pinKey(el.getAttribute('data-v')); },
  'set-pin': function () { changePin(); },
  'del-pin': function () { askPin('Rimuovi PIN', 'Inserisci il PIN attuale.', function (c) { if (c !== S.settings.pin) return 'PIN errato, riprova.'; S.settings.pin = ''; saveSettings(); toast('PIN rimosso.'); S.modal = null; renderModal(); go('settings', { focusSel: '[data-act="set-pin"]' }); return true; }); },
  'open-cats': function () { if (!S.D) return; go('cats'); },
  'cats-kind': function (el) { S.catsKind = el.getAttribute('data-v'); go('cats', { focusSel: '[data-act="cats-kind"].on' }); },
  'toggle-cat': function (el) {
    var k = S.catsKind, id = el.getAttribute('data-key'), h = S.user.hidden[k] = S.user.hidden[k] || {};
    if (h[id]) delete h[id]; else h[id] = 1;
    saveUser(); buildView(); go('cats', { focusSel: '[data-act="toggle-cat"][data-key="' + cssq(id) + '"]' });
  },
  'show-all-cats': function () { S.user.hidden[S.catsKind] = {}; saveUser(); buildView(); go('cats', { focusSel: '[data-act="cats-kind"].on' }); },
  'save-keys': function () {
    S.settings.tmdbKey = ($('#tmdb').value || '').trim(); S.settings.omdbKey = ($('#omdb').value || '').trim(); saveSettings();
    META.mem = {}; S.charts = null;
    if (!S.settings.tmdbKey) { toast('Chiavi salvate. Senza chiave TMDB le funzioni extra restano spente.'); return; }
    toast('Verifico le chiavi…');
    tmdbFetch('/configuration', {}).then(function () {
      if (!S.settings.omdbKey) { toast('Chiave TMDB valida. Le trame e le classifiche compaiono da ora.'); return; }
      return fetchJson('https://www.omdbapi.com/?apikey=' + encodeURIComponent(S.settings.omdbKey) + '&i=tt0111161').then(function (d) {
        toast(d && d.Response === 'True' ? 'Chiavi TMDB e OMDb valide.' : 'TMDB va bene, ma la chiave OMDb non è valida o non è ancora attiva (controlla l’email di attivazione).');
      }, function () { toast('TMDB va bene, ma OMDb non risponde. Controlla la chiave.'); });
    }).catch(function (e) { toast(e.message); });
  },
  'save-ua': function () { S.settings.ua = ($('#ua').value || '').trim(); saveSettings(); toast(S.settings.ua ? 'User-Agent salvato.' : 'Torno allo User-Agent predefinito.'); },
  reload: function () { start(true); },
  'clear-hist': function (el) {
    if (!el.__armed) { el.__armed = true; el.textContent = 'Conferma: cancella cronologia'; setTimeout(function () { if (document.contains(el)) { el.__armed = false; el.textContent = 'Cancella cronologia di visione'; } }, 4000); return; }
    S.user.prog = {}; S.user.plays = {}; S.user.watched = {}; S.user.lastEp = {}; saveUser(); toast('Cronologia cancellata.'); go('settings', { focusSel: '[data-act="clear-hist"]' });
  },
  'add-src': function () { S.form = { type: 'xtream', err: '' }; go('setup'); },
  'edit-src': function (el) { var id = el.getAttribute('data-key'); S.form = formFrom(S.sources.filter(function (x) { return x.id === id; })[0]); go('setup'); },
  'use-src': function (el) { S.activeId = el.getAttribute('data-key'); saveSources(); start(false); },
  'del-src': function (el) {
    if (!el.__armed) { el.__armed = true; el.textContent = 'Conferma eliminazione'; setTimeout(function () { if (document.contains(el)) { el.__armed = false; el.textContent = 'Elimina'; } }, 4000); return; }
    var id = el.getAttribute('data-key');
    S.sources = S.sources.filter(function (x) { return x.id !== id; });
    try { localStorage.removeItem('orbita.user.' + id); } catch (e) {}
    if (S.activeId === id) { S.activeId = S.sources[0] ? S.sources[0].id : null; S.D = null; S.V = null; }
    saveSources(); toast('Playlist eliminata.');
    if (S.activeId && S.D) go('settings'); else start(false);
  },
  ftype: function (el) { readForm(); S.form.type = el.getAttribute('data-v'); S.form.err = ''; go('setup', { focusSel: '[data-act="ftype"][data-v="' + S.form.type + '"]' }); },
  'save-src': function () { saveSource(); },
  demo: function () {
    var d = S.sources.filter(function (x) { return x.type === 'demo'; })[0];
    if (!d) { d = { id: 'demo', type: 'demo', name: 'Catalogo dimostrativo' }; S.sources.push(d); }
    S.activeId = d.id; saveSources(); start(false);
  }
};
function cssq(s) { return String(s).replace(/["\\]/g, '\\$&'); }
document.addEventListener('click', function (e) {
  var el = e.target.closest && e.target.closest('[data-act]');
  if (!el || el.disabled) return;
  var fn = ACT[el.getAttribute('data-act')];
  if (fn) { e.preventDefault(); fn(el); }
});

/* ================= chrome: clock, toast, hint ================= */
var toastT;
window.orbitaToast = function (m) { toast(m); };
function toast(msg) { var t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(function () { t.classList.remove('show'); }, 4200); }
function tick() { var d = new Date(); $('#clock').textContent = d.toLocaleDateString('it-IT', { weekday: 'short', day: 'numeric', month: 'short' }) + ' · ' + hhmm(d.getTime()); }
tick(); setInterval(tick, 20000);
if (!NATIVE) {
  var h = $('#hint');
  h.innerHTML = '<b>Anteprima web.</b> Usa <kbd>←</kbd> <kbd>↑</kbd> <kbd>→</kbd> <kbd>↓</kbd> e <kbd>Invio</kbd> come il telecomando, <kbd>Esc</kbd> per tornare indietro. Puoi anche cliccare.';
  h.hidden = false;
  setTimeout(function () { h.hidden = true; }, 14000);
  h.addEventListener('click', function () { h.hidden = true; });
}

/* ================= boot ================= */
if (!NATIVE && !S.sources.length) { S.sources.push({ id: 'demo', type: 'demo', name: 'Catalogo dimostrativo' }); S.activeId = 'demo'; saveSources(); }
if (!src() && S.sources.length) { S.activeId = S.sources[0].id; saveSources(); }
start(false);

})();
