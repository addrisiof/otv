# Orbita TV

App per Fire TV Stick (e Android TV) che legge playlist **Xtream Codes** o **M3U** e le mostra come un catalogo in stile streaming: locandine, voti, categorie, scheda dettaglio, stagioni ed episodi, TV in diretta con guida programmi, ricerca, La mia lista e Continua a guardare.

## Cosa c'è dentro

| Sezione | Cosa fa |
|---|---|
| **Home** | Titolo in evidenza a rotazione, poi le righe: Continua a guardare, Aggiunti di recente, I più votati, I più visti da te, La mia lista, I tuoi canali e le categorie del fornitore. |
| **Film / Serie TV** | Griglia con filtro per categoria e ordinamento (Recenti, Più votati, A–Z). |
| **Scheda** | Trama, anno, durata, voto, regia e cast (dati del server Xtream). Riprendi dal punto in cui eri, stagioni ed episodi con barra di avanzamento e «Visto». |
| **In diretta** | Vista Elenco (canali + pannello con programma in onda e successivi) e vista **Guida TV** a griglia sulle prossime 3 ore. Su/Giù nel lettore cambia canale. |
| **Programmi passati** | Catch-up per i canali Xtream con archivio: riguardi i programmi degli ultimi giorni con pausa e salti. |
| **Cerca** | Cerca insieme tra film, serie e canali. |
| **Impostazioni** | Più playlist, abbonamento e scadenza, buffer, lettore esterno, ultimo canale all'avvio, lingua audio e sottotitoli, PIN parentale, categorie nascoste, chiavi TMDB e OMDb. |

**Classifiche e novità da tutte le piattaforme**: tutte le righe mostrano solo titoli presenti nel tuo abbonamento.
- **Top 10 film e Top 10 serie della settimana**: una classifica unica che mescola la Top 10 ufficiale Netflix Italia, le tendenze del giorno e della settimana di TMDB e i titoli più seguiti su Prime Video, Disney+, NOW, Apple TV+, Paramount+ e le altre piattaforme disponibili in Italia. Chi compare su più fonti sale in classifica; sotto ogni titolo vedi su quali piattaforme è in tendenza.
- **Ultime uscite**: film usciti negli ultimi 6-9 mesi, al cinema o in streaming, dal più recente.
- **Nuovi episodi**: serie con episodi andati in onda nelle ultime 6 settimane.
- **Di tendenza questa settimana**: film e serie mescolati da tutte le fonti.
- **Di tendenza su Netflix / Prime Video / Disney+ / …**: una riga per ogni piattaforma, quando il tuo abbonamento ha abbastanza titoli in comune.

Senza chiave TMDB restano la Top 10 Netflix e le «Ultime uscite» ricavate dal catalogo.

**Trame e voti (TMDB e OMDb)**: con le chiavi gratuite la scheda mostra trama in italiano, tagline, cast e i voti TMDB, IMDb, Rotten Tomatoes e Metacritic.

Il lettore video è ExoPlayer (Media3): riproduce HLS, MPEG-TS, MP4 e MKV. Dalle Impostazioni scegli il buffer (Standard, Ampio, Massimo), la lingua audio e dei sottotitoli preferita, la dimensione e lo sfondo dei sottotitoli. Durante la visione, l'icona impostazioni del lettore permette di cambiare traccia audio, sottotitoli e velocità. Se un video non si decodifica, l'app lo segnala e puoi passare a un lettore esterno come VLC.

**Telecomando nel lettore**

- Sinistra / Destra: −10 / +10 secondi (film e serie)
- Riavvolgi / Avanti veloce: −30 / +30 secondi
- Su / Giù oppure CH+ / CH−: canale precedente o successivo (diretta)
- Menu: formato immagine (Adatta, Zoom, Riempi)
- Indietro: torna al catalogo e salva il punto di visione

## 1. Ottenere l'APK senza installare nulla sul PC (GitHub)

1. Crea un account gratuito su <https://github.com> e poi un **nuovo repository pubblico** (per esempio `orbita-tv`). Deve essere pubblico perché il Firestick possa scaricare l'APK senza login. Nel progetto non c'è nessun tuo dato: le credenziali IPTV restano solo sul Firestick.
2. Nella pagina del repository scegli **Add file → Upload files** e trascina **il contenuto** della cartella `orbita-tv` (non la cartella stessa). Conferma con **Commit changes**.
   - Se dopo il caricamento non vedi la cartella `.github` (succede su Mac perché è nascosta), creala a mano: **Add file → Create new file**, nome `.github/workflows/build.yml`, e incolla il contenuto del file `build.yml` incluso nello zip.
3. Apri la scheda **Actions**: parte la compilazione «Compila APK» (5–8 minuti). Quando diventa verde, nella colonna di destra del repository compare la release **latest** con il file `OrbitaTV.apk`.
4. Il link diretto all'APK è:

   ```
   https://github.com/TUO-UTENTE/orbita-tv/releases/download/latest/OrbitaTV.apk
   ```

Ogni volta che modifichi un file del progetto, l'APK viene ricompilato e il link resta lo stesso.

## 2. Installare sul Firestick

1. Sul Firestick installa l'app gratuita **Downloader** (di AFTVnews) dall'Appstore.
2. Vai su **Impostazioni → La mia Fire TV → Opzioni sviluppatore → Installa app sconosciute** e attiva **Downloader**.
   Se «Opzioni sviluppatore» non compare: **Impostazioni → La mia Fire TV → Informazioni**, seleziona il nome del dispositivo e premi il tasto centrale 7 volte.
3. Apri Downloader, scrivi il link del punto 1.4 e premi **Vai**. Al termine scegli **Installa**.
4. Orbita TV compare tra le app. Al primo avvio inserisci server, nome utente e password (oppure incolla il link M3U completo: se contiene username e password l'app li riconosce da sola e usa le API Xtream, che danno locandine, trame e voti).

Gli aggiornamenti si installano sopra la versione precedente senza perdere playlist, preferiti e cronologia, perché l'APK è sempre firmato con la stessa chiave (`app/orbita.keystore`).

## 3. In alternativa: compilare con Android Studio

Apri la cartella con Android Studio, attendi la sincronizzazione di Gradle e usa **Build → Build App Bundle(s) / APK(s) → Build APK(s)**. Per installarlo sul Firestick via rete: attiva **Debug ADB** nelle Opzioni sviluppatore e da terminale `adb connect IP-DEL-FIRESTICK` seguito da `adb install -r app-release.apk`.

## Cataloghi enormi: lingue e riorganizzazione

Se il fornitore ha contenuti in molte lingue, al primo accesso Orbita TV mostra la schermata **Quali lingue vuoi caricare?** e scarica solo le categorie scelte, una alla volta (per esempio 11 MB invece di 160 MB). La scelta si cambia da **Impostazioni → Playlist → Lingue**.

Con **Riorganizza automaticamente** attivo l'app:
- toglie le righe finte usate come separatori;
- pulisce i nomi («IT| RAI 1 FHD» → «Rai 1») e i titoli dei film («IT| Verity - 2026» → «Verity», anno 2026);
- accorpa le versioni FHD/HD/HEVC dello stesso canale: se una non parte, il lettore prova da solo la successiva;
- divide i canali italiani in Generalisti, Notizie, Sport, Calcio, Eventi live, Cinema, Intrattenimento, Documentari, Bambini, TV locali, Musica e radio, con la numerazione del digitale terrestre;
- per i canali evento mostra partita e orario nel riquadro «In onda»;
- rinomina le categorie di film e serie e toglie i doppioni.

La lista sul server non viene modificata: le regole si applicano a ogni aggiornamento.

## Chiavi TMDB e OMDb (gratuite)

1. **TMDB**: crea un account su <https://www.themoviedb.org>, poi vai su **Impostazioni → API** e richiedi una chiave per uso personale. Copia la «Chiave API» (v3) oppure il «Token di accesso in lettura».
2. **OMDb** (facoltativa, per IMDb e Rotten Tomatoes): richiedi la chiave gratuita su <https://www.omdbapi.com/apikey.aspx> e attivala dal link che arriva via email. Il piano gratuito permette 1.000 richieste al giorno.
3. In Orbita TV: **Impostazioni → Trame e voti da TMDB e OMDb**, incolla le chiavi e premi **Salva e verifica**.

Le chiavi restano sul Firestick e non finiscono nel progetto su GitHub. I dati vengono salvati sul dispositivo (30 giorni per le schede, 6 ore per le classifiche), quindi le richieste restano poche.

## Limiti da conoscere

- **«I più visti»** si basa sulla tua cronologia sul Firestick: i server Xtream e M3U non forniscono dati di popolarità globale.
- **Voti, trame e cast** arrivano dal server Xtream. Con un semplice link M3U ci sono solo titolo, logo e categoria.
- **Guida TV**: con Xtream viene letta canale per canale; con M3U serve un link XMLTV (dalla playlist o inserito a mano). I file `.xml.gz` richiedono un Fire OS recente.
- Il catalogo viene salvato sul dispositivo e aggiornato in automatico ogni 12 ore (o a mano dalle Impostazioni).
- Non ci sono ancora la registrazione dei programmi e la visione di più canali insieme (multi-view).
- Il catch-up funziona con i server Xtream che offrono l'archivio per quel canale.
- La Top 10 Netflix riguarda il catalogo Netflix: compaiono solo i titoli che il tuo fornitore ha. Il file Netflix contiene tutti i paesi, quindi l'app lo scarica al massimo ogni 3 giorni e tiene solo le righe dell'Italia.
- Le tendenze TMDB misurano l'interesse sul sito TMDB, non gli ascolti TV.
- L'abbinamento con TMDB usa titolo e anno: con nomi molto diversi dall'originale qualche titolo può restare senza scheda.

## Struttura del progetto

```
app/src/main/assets/www/index.html   interfaccia (HTML/CSS/JS, nessuna libreria esterna)
app/src/main/java/.../MainActivity.kt   WebView a schermo intero + proxy HTTP nativo
app/src/main/java/.../PlayerActivity.kt lettore Media3/ExoPlayer
.github/workflows/build.yml          compilazione automatica su GitHub
```

L'interfaccia funziona anche in un browser normale con dati dimostrativi: apri `index.html` e usa le frecce della tastiera come il telecomando.
